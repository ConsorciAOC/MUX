package cat.aoc.serveis.organismes.beans;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;


public class OficinaRegistreDir3 implements Serializable, Comparable<OficinaRegistreDir3>, Cloneable{


	private static final long serialVersionUID = -484191358601129200L;

	private String dir3;

	private String dir3Pare;
	
	private String dir3UnitatResponsable;

	private String ine10;

	private String nom;

	private String codiTipusVia;

	private String tipusVia;

	private String adressa;

	private String numeroVia;

	private String codiMunicipi;

	private String nomMunicipi;

	private String codiComarca;

	private String nomComarca;

	private String codiProvincia;

	private String nomProvincia;

	private String codiPostal;

	private String codiComunitat;

	private String nomComunitat;

	private String codiPais;

	private String nomPais;

	private String codiEntitatGeografica;

	private String nomEntitatGeografica;

	private String codiNivellAdministracio;

	private String nomNivellAdministracio;

	private String observacions;

	private String horariAtencio;
	
	private String diesInabils;
	
	private String observacionsAdreca;
	
	private String tipusOficina;
	
	private DadesContacte dadesContacte;
	
	private List<ServeisOficina> serveisOficina;
	
	private Set<Object> unitatsServides;

	private transient OficinaRegistreDir3 oficinaResponsable;
	

	public OficinaRegistreDir3(){
		;
	}

	public OficinaRegistreDir3(String ine10, String dir3, String dir3Pare, Set<Object> unitatsServides, String dir3UnitatResponsable, String nom, String codiTipusVia, String tipusVia, String adressa, String numeroVia, String codiMunicipi, String nomMunicipi, String codiComarca, String nomComarca, String codiProvincia, String nomProvincia, String codiPostal, String codiComunitat, String nomComunitat, String codiPais, String nomPais, String codiEntitatGeografica, String nomEntitatGeografica, String codiNivellAdministracio, String nomNivellAdministracio, String observacions, String horariAtencio, String diesInabils, String observacionsAdreca, String tipusOficina, List<ServeisOficina> serveisOficina, DadesContacte dadesContacte) {
		super();
		this.ine10 = ine10;
		this.dir3 = dir3;
		this.dir3Pare = dir3Pare;
		this.unitatsServides = unitatsServides;
		this.dir3UnitatResponsable = dir3UnitatResponsable;
		this.nom = nom;
		this.codiTipusVia = codiTipusVia;
		this.tipusVia = tipusVia;
		this.adressa = adressa;
		this.numeroVia = numeroVia;
		this.codiMunicipi = codiMunicipi;
		this.nomMunicipi = nomMunicipi;
		this.codiComarca = codiComarca;
		this.nomComarca = nomComarca;
		this.codiProvincia = codiProvincia;
		this.nomProvincia = nomProvincia;
		this.codiPostal = codiPostal;
		this.codiComunitat = codiComunitat;
		this.nomComunitat = nomComunitat;
		this.codiPais = codiPais;
		this.nomPais = nomPais;
		this.codiEntitatGeografica = codiEntitatGeografica;
		this.nomEntitatGeografica = nomEntitatGeografica;
		this.codiNivellAdministracio = codiNivellAdministracio;
		this.nomNivellAdministracio = nomNivellAdministracio;
		this.observacions = observacions;
		this.horariAtencio = horariAtencio;
		this.diesInabils = diesInabils;
		this.observacionsAdreca = observacionsAdreca;
		this.tipusOficina = tipusOficina;
		this.serveisOficina = serveisOficina;
		this.dadesContacte = dadesContacte;
		this.oficinaResponsable = null;
	}


	public String getIne10() {
		return ine10;
	}

	public void setIne10(String ine10) {
		this.ine10 = ine10;
	}

	public String getDir3() {
		return dir3;
	}

	public void setDir3(String dir3) {
		this.dir3 = dir3;
	}

	public String getDir3Pare() {
		return dir3Pare;
	}

	public void setDir3Pare(String dir3Pare) {
		this.dir3Pare = dir3Pare;
	}

	public String getDir3UnitatResponsable() {
		return this.dir3UnitatResponsable;
	}

	public void setDir3UnitatResponsable(String dir3UnitatResponsable) {
		this.dir3UnitatResponsable = dir3UnitatResponsable;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getCodiTipusVia() {
		return codiTipusVia;
	}

	public void setCodiTipusVia(String codiTipusVia) {
		this.codiTipusVia = codiTipusVia;
	}

	public String getTipusVia() {
		return tipusVia;
	}

	public void setTipusVia(String tipusVia) {
		this.tipusVia = tipusVia;
	}

	public String getAdressa() {
		return adressa;
	}

	public void setAdressa(String adressa) {
		this.adressa = adressa;
	}

	public String getNumeroVia() {
		return numeroVia;
	}

	public void setNumeroVia(String numeroVia) {
		this.numeroVia = numeroVia;
	}

	public String getCodiMunicipi() {
		return codiMunicipi;
	}

	public void setCodiMunicipi(String codiMunicipi) {
		this.codiMunicipi = codiMunicipi;
	}

	public String getNomMunicipi() {
		return nomMunicipi;
	}

	public void setNomMunicipi(String nomMunicipi) {
		this.nomMunicipi = nomMunicipi;
	}

	public String getCodiComarca() {
		return codiComarca;
	}

	public void setCodiComarca(String codiComarca) {
		this.codiComarca = codiComarca;
	}

	public String getNomComarca() {
		return nomComarca;
	}

	public void setNomComarca(String nomComarca) {
		this.nomComarca = nomComarca;
	}

	public String getCodiProvincia() {
		return codiProvincia;
	}

	public void setCodiProvincia(String codiProvincia) {
		this.codiProvincia = codiProvincia;
	}

	public String getNomProvincia() {
		return nomProvincia;
	}

	public void setNomProvincia(String nomProvincia) {
		this.nomProvincia = nomProvincia;
	}

	public String getCodiPostal() {
		return codiPostal;
	}

	public void setCodiPostal(String codiPostal) {
		this.codiPostal = codiPostal;
	}

	public String getCodiComunitat() {
		return codiComunitat;
	}

	public void setCodiComunitat(String codiComunitat) {
		this.codiComunitat = codiComunitat;
	}

	public String getNomComunitat() {
		return nomComunitat;
	}

	public void setNomComunitat(String nomComunitat) {
		this.nomComunitat = nomComunitat;
	}

	public String getCodiPais() {
		return codiPais;
	}

	public void setCodiPais(String codiPais) {
		this.codiPais = codiPais;
	}

	public String getNomPais() {
		return nomPais;
	}

	public void setNomPais(String nomPais) {
		this.nomPais = nomPais;
	}

	public String getCodiEntitatGeografica() {
		return codiEntitatGeografica;
	}

	public void setCodiEntitatGeografica(String codiEntitatGeografica) {
		this.codiEntitatGeografica = codiEntitatGeografica;
	}

	public String getNomEntitatGeografica() {
		return nomEntitatGeografica;
	}

	public void setNomEntitatGeografica(String nomEntitatGeografica) {
		this.nomEntitatGeografica = nomEntitatGeografica;
	}

	public String getCodiNivellAdministracio() {
		return codiNivellAdministracio;
	}

	public void setCodiNivellAdministracio(String codiNivellAdministracio) {
		this.codiNivellAdministracio = codiNivellAdministracio;
	}

	public String getNomNivellAdministracio() {
		return nomNivellAdministracio;
	}

	public void setNomNivellAdministracio(String nomNivellAdministracio) {
		this.nomNivellAdministracio = nomNivellAdministracio;
	}

	public String getObservacions() {
		return observacions;
	}

	public void setObservacions(String observacions) {
		this.observacions = observacions;
	}

	public String getHorariAtencio() {
		return horariAtencio;
	}

	public void setHorariAtencio(String horariAtencio) {
		this.horariAtencio = horariAtencio;
	}

	public String getDiesInabils() {
		return diesInabils;
	}

	public void setDiesInabils(String diesInabils) {
		this.diesInabils = diesInabils;
	}

	public String getObservacionsAdreca() {
		return observacionsAdreca;
	}

	public void setObservacionsAdreca(String observacionsAdreca) {
		this.observacionsAdreca = observacionsAdreca;
	}

	public String getTipusOficina() {
		return tipusOficina;
	}

	public void setTipusOficina(String tipusOficina) {
		this.tipusOficina = tipusOficina;
	}

	public List<ServeisOficina> getServeisOficina() {
		if(this.serveisOficina==null){
			this.serveisOficina = new LinkedList<>();
		}
		return this.serveisOficina;
	}

	public void setServeisOficina(List<ServeisOficina> serveisOficina) {
		this.serveisOficina = serveisOficina;
	}

	public DadesContacte getDadesContacte(){
		return this.dadesContacte;
	}

	public void setDadesContacte(DadesContacte dadesContacte){
		this.dadesContacte = dadesContacte;
	}

	public Set<Object> getUnitatsServides() {
		return unitatsServides;
	}

	public void setUnitatsServides(Set<Object> unitatsServides) {
		this.unitatsServides = unitatsServides;
	}

	public OficinaRegistreDir3 getOficinaResponsable(){
		return this.oficinaResponsable;
	}

	public void setOficinaResponsable(OficinaRegistreDir3 oficinaResponsable){
		this.oficinaResponsable = oficinaResponsable;
	}

	@Override
	public String toString(){
		boolean set = false;
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		if(this.dir3!=null){
			if(set){sb.append(", "); set = false;}
			sb.append("\"dir3\":\"");
			sb.append(this.dir3);
			sb.append("\"");
			set = true;
		}
		if(this.ine10!=null){
			if(set){sb.append(", "); set = false;}
			sb.append("\"ine10\":\"");
			sb.append(this.ine10);
			sb.append("\"");
			set = true;
		}
		if(this.nom!=null){
			if(set){sb.append(", "); set = false;}
			sb.append("\"nom\":\"");
			sb.append(this.nom);
			sb.append("\"");
		}
		sb.append("}");
		return sb.toString();
	}


	@Override
	public int compareTo(OficinaRegistreDir3 dir3) {
		if(dir3==null) return -100;
		return this.nom.compareTo(dir3.nom);
	}

	@Override
	public OficinaRegistreDir3 clone(){
		return new OficinaRegistreDir3(ine10, dir3, dir3Pare, unitatsServides, dir3UnitatResponsable, nom, codiTipusVia, tipusVia, adressa, numeroVia, codiMunicipi, nomMunicipi, codiComarca, nomComarca, codiProvincia, nomProvincia, codiPostal, codiComunitat, nomComunitat, codiPais, nomPais, codiEntitatGeografica, nomEntitatGeografica, codiNivellAdministracio, nomNivellAdministracio, observacions, horariAtencio, diesInabils, observacionsAdreca, tipusOficina, serveisOficina, dadesContacte);
	}
}
