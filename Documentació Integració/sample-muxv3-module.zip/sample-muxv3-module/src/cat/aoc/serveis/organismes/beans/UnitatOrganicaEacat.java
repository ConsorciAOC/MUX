package cat.aoc.serveis.organismes.beans;

import java.io.Serializable;

public class UnitatOrganicaEacat implements Serializable, Comparable<UnitatOrganicaEacat>{

	private static final long serialVersionUID = -484191358601129200L;

	private String ine10;
	
	private String ine5;
	
	private String nom;
	
	private String cif;
	
	private String poblacio;
	
	private String codiPostal;


	public UnitatOrganicaEacat(){
		;
	}

	public UnitatOrganicaEacat(String ine10, String ine5, String nom, String cif, String poblacio, String codiPostal){
		this.ine10 = ine10;
		this.ine5 = ine5;
		this.nom = nom;
		this.cif = cif;
		this.poblacio = poblacio;
		this.codiPostal = codiPostal;
	}

	public String getIne10() {
		return ine10;
	}

	public void setIne10(String ine10) {
		this.ine10 = ine10;
	}

	public String getIne5() {
		return ine5;
	}

	public void setIne5(String ine5) {
		this.ine5 = ine5;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getPoblacio() {
		return poblacio;
	}

	public void setPoblacio(String poblacio) {
		this.poblacio = poblacio;
	}

	public String getCodiPostal() {
		return codiPostal;
	}

	public void setCodiPostal(String codiPostal) {
		this.codiPostal = codiPostal;
	}

	@Override
	public int compareTo(UnitatOrganicaEacat o) {
		if(o==null) return -100;
		return this.ine10.compareTo(o.ine10);
	}

	@Override
	public String toString(){
		boolean set = false;
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		if(this.ine10!=null){
			if(set){sb.append(", "); set = false;}
			sb.append("\"ine10\":\"");
			sb.append(this.ine10);
			sb.append("\"");
			set = true;
		}
		if(this.nom!=null){
			if(set){sb.append(", "); set = false;}
			sb.append("\"nom\":\"");
			sb.append(this.nom);
			sb.append("\"");
		}
		sb.append("}");
		return sb.toString();
	}
}
