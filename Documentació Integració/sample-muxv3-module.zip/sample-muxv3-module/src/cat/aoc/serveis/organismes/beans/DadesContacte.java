package cat.aoc.serveis.organismes.beans;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class DadesContacte extends HashMap<String, List<String>> implements Cloneable {


	private static final long serialVersionUID = 952259441808063015L;

	private static final Map<String, String> _tipus = new HashMap<>();
	
	static{
		_tipus.put("C", "centraleta");
		_tipus.put("E", "email");
		_tipus.put("F", "fax");
		_tipus.put("O", "altres");
		_tipus.put("T", "telefon");
		_tipus.put("U", "URL");
	}


	public DadesContacte(){
		super();
	}

	private DadesContacte(DadesContacte cloned){
		super();
		this.putAll(cloned);
	}

	public void addDadaContacte(String tipus, String valor){
		String key = tradueixTipus(tipus);
		if(!super.containsKey(key)){
			super.put(key, new LinkedList<String>());
		}
		super.get(key).add(valor);
	}

	public List<String> getDadesContacte(String tipus){
		String key = tradueixTipus(tipus);
		if(!super.containsKey(key)){
			return Collections.emptyList();
		}
		return super.get(key);
	}

	public Set<String> getTipus(){
		return super.keySet();
	}
	
	public static Collection<String> getTipusConeguts(){
		return _tipus.values();
	}
	
	private static String tradueixTipus(String tipus){
		String uTipus = tipus.toUpperCase();
		return _tipus.getOrDefault(uTipus, tipus);
	}
	
	@Override
	public DadesContacte clone(){
		return new DadesContacte(this);
	}
}
