package cat.aoc.serveis.organismes.beans;

import java.io.Serializable;
import java.util.Set;


public class UnitatOrganicaDir3 implements Serializable, Comparable<UnitatOrganicaDir3>, Cloneable{


	private static final long serialVersionUID = -484191358601129200L;

	private String dir3;

	private String dir3Pare;
	
	private String ine10;

	private String nom;

	private String cif;

	private String codiExtern;

	private String codiTipusVia;

	private String tipusVia;

	private String adressa;

	private String numeroVia;

	private String codiMunicipi;

	private String nomMunicipi;

	private String codiComarca;

	private String nomComarca;

	private String codiProvincia;

	private String nomProvincia;

	private String codiPostal;

	private String codiComunitat;

	private String nomComunitat;

	private String codiPais;

	private String nomPais;

	private String codiAmbitTerritorial;

	private String nomAmbitTerritorial;

	private String codiEntitatGeografica;

	private String nomEntitatGeografica;

	private String codiNivellAdministracio;

	private String nomNivellAdministracio;

	private String codiTipusEntitatPublica;

	private String nomTipusEntitatPublica;

	private String codiTipusUnitatOrganica;

	private String nomTipusUnitatOrganica;

	private DadesContacte dadesContacte;
	
	private Set<Object> oficinesAssociades;
	
	private transient UnitatOrganicaDir3 unitatPare;


	public UnitatOrganicaDir3(){
		;
	}

	public UnitatOrganicaDir3(String ine10, String dir3, String dir3Pare, Set<Object> oficinesAssociades, String nom, String cif, String codiExtern, String codiTipusVia, String tipusVia, String adressa, String numeroVia, String codiMunicipi, String nomMunicipi, String codiComarca, String nomComarca, String codiProvincia, String nomProvincia, String codiPostal, String codiComunitat, String nomComunitat, String codiPais, String nomPais, String codiAmbitTerritorial, String nomAmbitTerritorial, String codiEntitatGeografica, String nomEntitatGeografica, String codiNivellAdministracio, String nomNivellAdministracio, String codiTipusEntitatPublica,	String nomTipusEntitatPublica, String codiTipusUnitatOrganica,	String nomTipusUnitatOrganica, DadesContacte dadesContacte) {
		super();
		this.ine10 = ine10;
		this.dir3 = dir3;
		this.dir3Pare = dir3Pare;
		this.oficinesAssociades = oficinesAssociades;
		this.nom = nom;
		this.cif = cif;
		this.codiExtern = codiExtern;
		this.codiTipusVia = codiTipusVia;
		this.tipusVia = tipusVia;
		this.adressa = adressa;
		this.numeroVia = numeroVia;
		this.codiMunicipi = codiMunicipi;
		this.nomMunicipi = nomMunicipi;
		this.codiComarca = codiComarca;
		this.nomComarca = nomComarca;
		this.codiProvincia = codiProvincia;
		this.nomProvincia = nomProvincia;
		this.codiPostal = codiPostal;
		this.codiComunitat = codiComunitat;
		this.nomComunitat = nomComunitat;
		this.codiPais = codiPais;
		this.nomPais = nomPais;
		this.codiAmbitTerritorial = codiAmbitTerritorial;
		this.nomAmbitTerritorial = nomAmbitTerritorial;
		this.codiEntitatGeografica = codiEntitatGeografica;
		this.nomEntitatGeografica = nomEntitatGeografica;
		this.codiNivellAdministracio = codiNivellAdministracio;
		this.nomNivellAdministracio = nomNivellAdministracio;
		this.codiTipusEntitatPublica = codiTipusEntitatPublica;
		this.nomTipusEntitatPublica = nomTipusEntitatPublica;
		this.codiTipusUnitatOrganica = codiTipusUnitatOrganica;
		this.nomTipusUnitatOrganica = nomTipusUnitatOrganica;
		this.dadesContacte = dadesContacte;
		this.unitatPare = null;
	}


	public String getIne10() {
		return ine10;
	}

	public void setIne10(String ine10) {
		this.ine10 = ine10;
	}

	public String getDir3() {
		return dir3;
	}

	public void setDir3(String dir3) {
		this.dir3 = dir3;
	}

	public String getDir3Pare() {
		return dir3Pare;
	}

	public void setDir3Pare(String dir3Pare) {
		this.dir3Pare = dir3Pare;
	}
	
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getCodiTipusVia() {
		return codiTipusVia;
	}

	public void setCodiTipusVia(String codiTipusVia) {
		this.codiTipusVia = codiTipusVia;
	}

	public String getTipusVia() {
		return tipusVia;
	}

	public void setTipusVia(String tipusVia) {
		this.tipusVia = tipusVia;
	}

	public String getAdressa() {
		return adressa;
	}

	public void setAdressa(String adressa) {
		this.adressa = adressa;
	}

	public String getNumeroVia() {
		return numeroVia;
	}

	public void setNumeroVia(String numeroVia) {
		this.numeroVia = numeroVia;
	}

	public String getCodiMunicipi() {
		return codiMunicipi;
	}

	public void setCodiMunicipi(String codiMunicipi) {
		this.codiMunicipi = codiMunicipi;
	}

	public String getNomMunicipi() {
		return nomMunicipi;
	}

	public void setNomMunicipi(String nomMunicipi) {
		this.nomMunicipi = nomMunicipi;
	}

	public String getCodiComarca() {
		return codiComarca;
	}

	public void setCodiComarca(String codiComarca) {
		this.codiComarca = codiComarca;
	}

	public String getNomComarca() {
		return nomComarca;
	}

	public void setNomComarca(String nomComarca) {
		this.nomComarca = nomComarca;
	}

	public String getCodiProvincia() {
		return codiProvincia;
	}

	public void setCodiProvincia(String codiProvincia) {
		this.codiProvincia = codiProvincia;
	}

	public String getNomProvincia() {
		return nomProvincia;
	}

	public void setNomProvincia(String nomProvincia) {
		this.nomProvincia = nomProvincia;
	}

	public String getCodiPostal() {
		return codiPostal;
	}

	public void setCodiPostal(String codiPostal) {
		this.codiPostal = codiPostal;
	}

	public String getCodiComunitat() {
		return codiComunitat;
	}

	public void setCodiComunitat(String codiComunitat) {
		this.codiComunitat = codiComunitat;
	}

	public String getNomComunitat() {
		return nomComunitat;
	}

	public void setNomComunitat(String nomComunitat) {
		this.nomComunitat = nomComunitat;
	}

	public String getCodiPais() {
		return codiPais;
	}

	public void setCodiPais(String codiPais) {
		this.codiPais = codiPais;
	}

	public String getNomPais() {
		return nomPais;
	}

	public void setNomPais(String nomPais) {
		this.nomPais = nomPais;
	}

	public String getCodiAmbitTerritorial() {
		return codiAmbitTerritorial;
	}

	public void setCodiAmbitTerritorial(String codiAmbitTerritorial) {
		this.codiAmbitTerritorial = codiAmbitTerritorial;
	}

	public String getNomAmbitTerritorial() {
		return nomAmbitTerritorial;
	}

	public void setNomAmbitTerritorial(String nomAmbitTerritorial) {
		this.nomAmbitTerritorial = nomAmbitTerritorial;
	}

	public String getCodiEntitatGeografica() {
		return codiEntitatGeografica;
	}

	public void setCodiEntitatGeografica(String codiEntitatGeografica) {
		this.codiEntitatGeografica = codiEntitatGeografica;
	}

	public String getNomEntitatGeografica() {
		return nomEntitatGeografica;
	}

	public void setNomEntitatGeografica(String nomEntitatGeografica) {
		this.nomEntitatGeografica = nomEntitatGeografica;
	}

	public String getCodiNivellAdministracio() {
		return codiNivellAdministracio;
	}

	public void setCodiNivellAdministracio(String codiNivellAdministracio) {
		this.codiNivellAdministracio = codiNivellAdministracio;
	}

	public String getNomNivellAdministracio() {
		return nomNivellAdministracio;
	}

	public void setNomNivellAdministracio(String nomNivellAdministracio) {
		this.nomNivellAdministracio = nomNivellAdministracio;
	}

	public String getCodiTipusEntitatPublica() {
		return codiTipusEntitatPublica;
	}

	public void setCodiTipusEntitatPublica(String codiTipusEntitatPublica) {
		this.codiTipusEntitatPublica = codiTipusEntitatPublica;
	}

	public String getNomTipusEntitatPublica() {
		return nomTipusEntitatPublica;
	}

	public void setNomTipusEntitatPublica(String nomTipusEntitatPublica) {
		this.nomTipusEntitatPublica = nomTipusEntitatPublica;
	}

	public String getCodiTipusUnitatOrganica() {
		return codiTipusUnitatOrganica;
	}

	public void setCodiTipusUnitatOrganica(String codiTipusUnitatOrganica) {
		this.codiTipusUnitatOrganica = codiTipusUnitatOrganica;
	}

	public String getNomTipusUnitatOrganica() {
		return nomTipusUnitatOrganica;
	}

	public void setNomTipusUnitatOrganica(String nomTipusUnitatOrganica) {
		this.nomTipusUnitatOrganica = nomTipusUnitatOrganica;
	}

	public String getCodiExtern() {
		return codiExtern;
	}

	public void setCodiExtern(String codiExtern) {
		this.codiExtern = codiExtern;
	}

	public DadesContacte getDadesContacte(){
		return this.dadesContacte;
	}

	public void setDadesContacte(DadesContacte dadesContacte){
		this.dadesContacte = dadesContacte;
	}

	public Set<Object> getOficinesAssociades() {
		return oficinesAssociades;
	}

	public void setOficinesAssociades(Set<Object> oficinesAssociades) {
		this.oficinesAssociades = oficinesAssociades;
	}

	public UnitatOrganicaDir3 getUnitatPare(){
		return this.unitatPare;
	}

	public 	void setUnitatPare(UnitatOrganicaDir3 unitatPare){
		this.unitatPare = unitatPare;
	}

	@Override
	public String toString(){
		boolean set = false;
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		if(this.dir3!=null){
			if(set){sb.append(", "); set = false;}
			sb.append("\"dir3\":\"");
			sb.append(this.dir3);
			sb.append("\"");
			set = true;
		}
		if(this.ine10!=null){
			if(set){sb.append(", "); set = false;}
			sb.append("\"ine10\":\"");
			sb.append(this.ine10);
			sb.append("\"");
			set = true;
		}
		if(this.nom!=null){
			if(set){sb.append(", "); set = false;}
			sb.append("\"nom\":\"");
			sb.append(this.nom);
			sb.append("\"");
		}
		sb.append("}");
		return sb.toString();
	}


	@Override
	public int compareTo(UnitatOrganicaDir3 dir3) {
		if(dir3==null) return -100;
		return this.nom.compareTo(dir3.nom);
	}

	@Override
	public UnitatOrganicaDir3 clone(){
		return new UnitatOrganicaDir3(ine10, dir3, dir3Pare, oficinesAssociades, nom, cif, codiExtern, codiTipusVia, tipusVia, adressa, numeroVia, codiMunicipi, nomMunicipi, codiComarca, nomComarca, codiProvincia, nomProvincia, codiPostal, codiComunitat, nomComunitat, codiPais, nomPais, codiAmbitTerritorial, nomAmbitTerritorial, codiEntitatGeografica, nomEntitatGeografica, codiNivellAdministracio, nomNivellAdministracio, codiTipusEntitatPublica, nomTipusEntitatPublica, codiTipusUnitatOrganica, nomTipusUnitatOrganica, dadesContacte);
	}
}
