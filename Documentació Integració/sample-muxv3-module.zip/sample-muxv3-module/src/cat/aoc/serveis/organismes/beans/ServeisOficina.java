package cat.aoc.serveis.organismes.beans;

import java.io.Serializable;

public class ServeisOficina implements Serializable{

	private static final long serialVersionUID = -1167810430922349156L;

	private String codi;
	
	private String descripcio;


	public ServeisOficina(){
		;
	}

	public ServeisOficina(String codi, String descripcio){
		this.codi = codi;
		this.descripcio = descripcio;
	}

	public String getCodi() {
		return codi;
	}

	public void setCodi(String codi) {
		this.codi = codi;
	}

	public String getDescripcio() {
		return descripcio;
	}

	public void setDescripcio(String descripcio) {
		this.descripcio = descripcio;
	}
}
