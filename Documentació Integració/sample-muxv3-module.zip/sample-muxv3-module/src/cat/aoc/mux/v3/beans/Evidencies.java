package cat.aoc.mux.v3.beans;

import java.io.Serializable;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Map;


public class Evidencies extends LinkedList<Evidencia> implements Serializable{

	private static final long serialVersionUID = -4044756011096071950L;

	private static final Comparator<Evidencia> SORTER = new Comparator<Evidencia>(){

		@Override
		public int compare(Evidencia o1, Evidencia o2) {
			if(o1==null && o2==null) return 0;
			if(o1==null && o2!=null) return -1;
			if(o1!=null && o2==null) return 1;
			return ((Long)o1.getCreation()).compareTo(o2.getCreation());
		}
	};


	public Evidencies(){
		super();
	}

	public void push(String authorization, byte[] request, Map<String, String> responseHeaders, byte[] response, boolean connectTimedOut, boolean readTimedOut, int elapsedTime){
		super.add(new Evidencia(authorization, request, responseHeaders, response, connectTimedOut, readTimedOut, elapsedTime));
		Collections.sort(this, SORTER);
	}
}