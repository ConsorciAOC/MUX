package cat.aoc.mux.v3.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class Assentaments implements Serializable {


	private static final long serialVersionUID = 3441563915266189601L;

	private Entrada entrada;

	private Sortida sortida;


	public Entrada getEntrada() {
		return entrada;
	}

	public Entrada setEntrada(Entrada entrada) {
		return this.entrada = entrada;
	}

	public Sortida getSortida() {
		return sortida;
	}

	public Sortida setSortida(Sortida sortida) {
		return this.sortida = sortida;
	}
}
