package cat.aoc.mux.v3.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class Registres implements Serializable {

	private static final long serialVersionUID = 5227353570758217695L;

	private Origen origen;

	private Desti desti;


	public Origen getOrigen() {
		return origen;
	}

	public Origen setOrigen(Origen origen) {
		return this.origen = origen;
	}

	public Desti getDesti() {
		return desti;
	}

	public Desti setDesti(Desti desti) {
		return this.desti = desti;
	}
}
