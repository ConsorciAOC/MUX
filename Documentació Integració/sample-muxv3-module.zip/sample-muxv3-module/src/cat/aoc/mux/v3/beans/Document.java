package cat.aoc.mux.v3.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonGetter;

import cat.aoc.mux.v3.beans.types.KeyValueTranslator;


public class Document implements Serializable {

	private static final long serialVersionUID = 5158772029930707010L;

	private String CSVSignatura;

	private String CSV;

	private Date dataAlta;

	private Date dataDocument;

	private String descripcio;

	private KeyValueTranslator estatElaboracio;

	private String formatFitxer;

	private byte[] hash;
	
	private String hashAlgoritme;

	private String identificadorDocumentOrigen;

	private String identificadorDocumentExtern;

	private String nomFitxer;

	private String nomNatural;

	private KeyValueTranslator origen;

	private String referenciaSignatura;

	private String regulacioGeneracioCSVSignatura;

	private Long tamany;

	private KeyValueTranslator tipusDocumental;

	private KeyValueTranslator tipusDocumentalSICRES;

	private KeyValueTranslator tipusSignatura;

	private String URLDocumentExtern;

	private String uuid;

	private TipusTransaccio tipusAssentament;

	private String versioNTI;

	private String identificador;

	private String organ;

	// CAMPS AFEGITS DEGUT A DESA'L

	private KeyValueTranslator nivellAcces;

	private KeyValueTranslator classificacioENS;

	private KeyValueTranslator sensibilitatDadesCaracterPersonal;

	private Boolean documentEssencial;

	private String idioma;

	private String codiClassificacio;

	private String nomClassificacio;

	private String codiSIA;

	private String identificadorExpedientDesal;

	private String codiINE;

	private String codiServei;

	private Integer contingut;

	private List<String> interessat;

	private String usuari;

	private String identificadorExpedientExtern;

	private String numeroRegistre;
	
	private Map<String, String> infoAddicional;


	@JsonGetter("CSVSignatura")
	public String getCSVSignatura() {
		return CSVSignatura;
	}

	public void setCSVSignatura(String csvSignatura) {
		this.CSVSignatura = csvSignatura;
	}

	@JsonGetter("CSV")
	public String getCSV() {
		return CSV;
	}

	public void setCSV(String csv) {
		this.CSV = csv;
	}

	public Date getDataAlta() {
		return dataAlta;
	}

	public void setDataAlta(Date dataAlta) {
		this.dataAlta = dataAlta;
	}

	public Date getDataDocument() {
		return dataDocument;
	}

	public void setDataDocument(Date dataDocument) {
		this.dataDocument = dataDocument;
	}

	public String getDescripcio() {
		return descripcio;
	}

	public void setDescripcio(String descripcio) {
		this.descripcio = descripcio;
	}

	public KeyValueTranslator getEstatElaboracio() {
		return estatElaboracio;
	}

	public void setEstatElaboracio(KeyValueTranslator estatElaboracio) {
		this.estatElaboracio = estatElaboracio;
	}

	public String getFormatFitxer() {
		return formatFitxer;
	}

	public void setFormatFitxer(String formatFitxer) {
		this.formatFitxer = formatFitxer;
	}

	public byte[] getHash() {
		return hash;
	}

	public void setHash(byte[] hash) {
		this.hash = hash;
	}

	public String getHashAlgoritme() {
		return hashAlgoritme;
	}

	public void setHashAlgoritme(String hashAlgoritme) {
		this.hashAlgoritme = hashAlgoritme;
	}

	public String getIdentificadorDocumentOrigen() {
		return identificadorDocumentOrigen;
	}

	public void setIdentificadorDocumentOrigen(String identificadorDocumentOrigen) {
		this.identificadorDocumentOrigen = identificadorDocumentOrigen;
	}

	public String getIdentificadorDocumentExtern() {
		return identificadorDocumentExtern;
	}

	public void setIdentificadorDocumentExtern(String identificadorDocumentExtern) {
		this.identificadorDocumentExtern = identificadorDocumentExtern;
	}

	public String getNomFitxer() {
		return nomFitxer;
	}

	public void setNomFitxer(String nomFitxer) {
		this.nomFitxer = nomFitxer;
	}

	public String getNomNatural() {
		return nomNatural;
	}

	public void setNomNatural(String nomNatural) {
		this.nomNatural = nomNatural;
	}

	public KeyValueTranslator getOrigen() {
		return origen;
	}

	public void setOrigen(KeyValueTranslator origen) {
		this.origen = origen;
	}

	public String getReferenciaSignatura() {
		return referenciaSignatura;
	}

	public void setReferenciaSignatura(String referenciaSignatura) {
		this.referenciaSignatura = referenciaSignatura;
	}

	public String getRegulacioGeneracioCSVSignatura() {
		return regulacioGeneracioCSVSignatura;
	}

	public void setRegulacioGeneracioCSVSignatura(String regulacioGeneracioCSVSignatura) {
		this.regulacioGeneracioCSVSignatura = regulacioGeneracioCSVSignatura;
	}

	public Long getTamany() {
		return tamany;
	}

	public void setTamany(Long tamany) {
		this.tamany = tamany;
	}

	public KeyValueTranslator getTipusDocumental() {
		return tipusDocumental;
	}

	public void setTipusDocumental(KeyValueTranslator tipusDocumental) {
		this.tipusDocumental = tipusDocumental;
	}

	public KeyValueTranslator getTipusDocumentalSICRES() {
		return tipusDocumentalSICRES;
	}

	public void setTipusDocumentalSICRES(KeyValueTranslator tipusDocumentalSICRES) {
		this.tipusDocumentalSICRES = tipusDocumentalSICRES;
	}

	public KeyValueTranslator getTipusSignatura() {
		return tipusSignatura;
	}

	public void setTipusSignatura(KeyValueTranslator tipusSignatura) {
		this.tipusSignatura = tipusSignatura;
	}

	@JsonGetter("URLDocumentExtern")
	public String getURLDocumentExtern() {
		return URLDocumentExtern;
	}

	public void setURLDocumentExtern(String uRLDocumentExtern) {
		URLDocumentExtern = uRLDocumentExtern;
	}

	public String getUUID() {
		return uuid;
	}

	public void setUUID(String uuid) {
		this.uuid = uuid;
	}

	public TipusTransaccio getTipusAssentament() {
		return tipusAssentament;
	}

	public void setTipusAssentament(TipusTransaccio tipusAssentament) {
		this.tipusAssentament = tipusAssentament;
	}

	public String getVersioNTI() {
		return versioNTI;
	}

	public void setVersioNTI(String versioNTI) {
		this.versioNTI = versioNTI;
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public String getOrgan() {
		return organ;
	}

	public void setOrgan(String organ) {
		this.organ = organ;
	}

	// GETTERS SETTERS DELS CAMPS AFEGITS DEGUT A DESA'L

	public KeyValueTranslator getNivellAcces() {
		return nivellAcces;
	}

	public void setNivellAcces(KeyValueTranslator nivellAcces) {
		this.nivellAcces = nivellAcces;
	}

	public KeyValueTranslator getClassificacioENS() {
		return classificacioENS;
	}

	public void setClassificacioENS(KeyValueTranslator classificacioENS) {
		this.classificacioENS = classificacioENS;
	}

	public KeyValueTranslator getSensibilitatDadesCaracterPersonal() {
		return sensibilitatDadesCaracterPersonal;
	}

	public void setSensibilitatDadesCaracterPersonal(KeyValueTranslator sensibilitatDadesCaracterPersonal) {
		this.sensibilitatDadesCaracterPersonal = sensibilitatDadesCaracterPersonal;
	}

	public Boolean getDocumentEssencial() {
		return documentEssencial;
	}

	public void setDocumentEssencial(Boolean documentEssencial) {
		this.documentEssencial = documentEssencial;
	}

	public String getIdioma() {
		return idioma;
	}

	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}

	public String getCodiClassificacio() {
		return codiClassificacio;
	}

	public void setCodiClassificacio(String codiClassificacio) {
		this.codiClassificacio = codiClassificacio;
	}

	public String getNomClassificacio() {
		return nomClassificacio;
	}

	public void setNomClassificacio(String nomClassificacio) {
		this.nomClassificacio = nomClassificacio;
	}

	public String getCodiSIA() {
		return codiSIA;
	}

	public void setCodiSIA(String codiSIA) {
		this.codiSIA = codiSIA;
	}

	public String getIdentificadorExpedientDesal() {
		return identificadorExpedientDesal;
	}

	public void setIdentificadorExpedientDesal(String identificadorExpedientDesal) {
		this.identificadorExpedientDesal = identificadorExpedientDesal;
	}

	public String getCodiINE() {
		return codiINE;
	}

	public void setCodiINE(String codiINE) {
		this.codiINE = codiINE;
	}

	public String getCodiServei() {
		return codiServei;
	}

	public void setCodiServei(String codiServei) {
		this.codiServei = codiServei;
	}

	public Integer getContingut() {
		return contingut;
	}

	public void setContingut(Integer contingut) {
		this.contingut = contingut;
	}

	public List<String> getInteressat() {
		return interessat;
	}

	public void setInteressat(List<String> interessat) {
		this.interessat = interessat;
	}

	public String getUsuari() {
		return usuari;
	}

	public void setUsuari(String usuari) {
		this.usuari = usuari;
	}

	public String getIdentificadorExpedientExtern() {
		return identificadorExpedientExtern;
	}

	public void setIdentificadorExpedientExtern(String identificadorExpedientExtern) {
		this.identificadorExpedientExtern = identificadorExpedientExtern;
	}

	public String getNumeroRegistre() {
		return numeroRegistre;
	}

	public void setNumeroRegistre(String numeroRegistre) {
		this.numeroRegistre = numeroRegistre;
	}

	public Map<String, String> getInfoAddicional() {
		return infoAddicional;
	}

	public void setInfoAddicional(Map<String, String> infoAddicional) {
		this.infoAddicional = infoAddicional;
	}
}
