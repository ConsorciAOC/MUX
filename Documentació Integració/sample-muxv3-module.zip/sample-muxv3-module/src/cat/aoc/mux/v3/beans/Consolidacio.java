package cat.aoc.mux.v3.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class Consolidacio implements Serializable {

    private static final long serialVersionUID = 5128234827911503094L;

    private String numeroAssentament;

    private String dataAssentament;

    private String dataPresentacio;

    private byte[] evidencia;


    public String getNumeroAssentament() {
        return numeroAssentament;
    }

    public void setNumeroAssentament(String numeroAssentament) {
        this.numeroAssentament = numeroAssentament;
    }

    public String getDataAssentament() {
        return dataAssentament;
    }

    public void setDataAssentament(String dataAssentament) {
        this.dataAssentament = dataAssentament;
    }

    public String getDataPresentacio() {
        return dataPresentacio;
    }

    public void setDataPresentacio(String dataPresentacio) {
        this.dataPresentacio = dataPresentacio;
    }

    public void setEvidencia(byte[] evidencia) {
        this.evidencia = evidencia;
    }

    public byte[] getEvidencia() {
        return evidencia;
    }
}
