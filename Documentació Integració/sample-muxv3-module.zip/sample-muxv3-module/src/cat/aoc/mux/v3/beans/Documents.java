package cat.aoc.mux.v3.beans;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedHashMap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import cat.aoc.mux.v3.beans.types.TransactionDocuments;


@JsonInclude(Include.NON_NULL)
public class Documents extends LinkedHashMap<String, Document> implements Serializable {

	private static final String ID_MANDATORY = "El document ha de tenir un identificador UUID";

	private static final long serialVersionUID = 4076782283119804223L;


	public Documents(){
		;
	}

	public Documents(Document document) {
		super.put(document.getUUID(), document);
	}

	public Documents(Collection<Document> documents) {
		for(Document document:documents){
			super.put(document.getUUID(), document);
		}
	}

	public Collection<Document> get() {
		return super.values();
	}

	public Collection<Document> addAll(Collection<Document> documents) {
		documents.forEach((document) -> {
			if (document.getUUID() == null) {
				throw new IllegalArgumentException(ID_MANDATORY);
			}
			super.put(document.getUUID(), document);
		});
		return super.values();
	}

	public void add(Document document) {
		if (document.getUUID() == null) {
			throw new IllegalArgumentException(ID_MANDATORY);
		}
		super.put(document.getUUID(), document);
	}

	public static Documents fromTransactionDocuments(TransactionDocuments transactionDocuments){
		Documents documents = new Documents();

		if(transactionDocuments!=null){
			for(Document document:transactionDocuments.values()){
				documents.add(document);
			}
		}

		return documents;
	}
}
