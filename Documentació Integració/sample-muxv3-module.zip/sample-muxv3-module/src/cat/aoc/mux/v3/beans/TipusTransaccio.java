package cat.aoc.mux.v3.beans;


public enum TipusTransaccio {
	E,	// ENTRADA
	S,	// SORTIDA
	ES	// ENTRADA_I_SORTIDA
}
