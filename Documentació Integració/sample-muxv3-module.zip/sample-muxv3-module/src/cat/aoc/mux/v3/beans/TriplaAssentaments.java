package cat.aoc.mux.v3.beans;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class TriplaAssentaments implements Serializable {

	
    private static final long serialVersionUID = 3441563915266189601L;

    private List<Assentament> principal;

    private List<Assentament> auxiliar;

    private Consolidacio consolidacio;


    public List<Assentament> getPrincipal() {
        return principal;
    }

    public List<Assentament> setPrincipal(List<Assentament> principal) {
        return this.principal = principal;
    }

    @JsonIgnore
    public Assentament addPrincipal(Assentament principal) {
    	if(this.principal==null){
    		this.principal = new LinkedList<>();
    	}
        this.principal.add(0, principal);
        return principal;
    }

    @JsonIgnore
    public boolean getResultatPrincipal(){
    	if(this.principal!=null && this.principal.size()>0){
    		return this.principal.get(0).getResultat();
    	}

        return false;
    }

    @JsonIgnore
    public String getNumeroAssentamentPrincipal(){
    	if(this.principal!=null && this.principal.size()>0){
    		return this.principal.get(0).getNumeroAssentament();
    	}

        return null;
    }

    public List<Assentament> getAuxiliar() {
        return auxiliar;
    }

    public List<Assentament> setAuxiliar(List<Assentament> auxiliar) {
        return this.auxiliar = auxiliar;
    }

    @JsonIgnore
    public Assentament addAuxiliar(Assentament auxiliar) {
    	if(this.auxiliar==null){
    		this.auxiliar = new LinkedList<>();
    	}
        this.auxiliar.add(0, auxiliar);
        return auxiliar;
    }

    @JsonIgnore
    public boolean getResultatAuxiliar(){
    	if(this.auxiliar!=null && this.auxiliar.size()>0){
    		return this.auxiliar.get(0).getResultat();
    	}

        return false;
    }

    @JsonIgnore
    public String getNumeroAssentamentAuxiliar(){
    	if(this.auxiliar!=null && this.auxiliar.size()>0){
    		return this.auxiliar.get(0).getNumeroAssentament();
    	}

        return null;
    }

    public Consolidacio getConsolidacio() {
        return consolidacio;
    }

    public Consolidacio setConsolidacio(Consolidacio consolidat) {
        return this.consolidacio = consolidat;
    }
}
