package cat.aoc.mux.v3.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class InstanciaGenerica implements Serializable {


	private static final long serialVersionUID = 6040576664088515898L;

	private String exposa;
	
	private String solicita;


	public String getExposa() {
		return exposa;
	}

	public void setExposa(String exposa) {
		this.exposa = exposa;
	}

	public String getSolicita() {
		return solicita;
	}

	public void setSolicita(String solicita) {
		this.solicita = solicita;
	}
}
