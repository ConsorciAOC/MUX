package cat.aoc.mux.v3.beans;

import java.io.Serializable;


public class UnitatTramitadora implements Serializable {

	private static final long serialVersionUID = 8372583758366166170L;

	private String codi;

    private String nom;


    public UnitatTramitadora() {
    }

    public UnitatTramitadora(String codi, String nom) {
        this.codi = codi;
        this.nom = nom;
    }

	public String getCodi() {
		return codi;
	}

	public void setCodi(String codi) {
		this.codi = codi;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
}
