package cat.aoc.mux.v3.beans;

import java.io.Serializable;

import cat.aoc.mux.v3.beans.types.KeyValueTranslator;


public abstract class Persona implements Serializable{

	private static final long serialVersionUID = 5175124209381138447L;

	private KeyValueTranslator tipusIdentificador;

	private String identificador;
	
	private InformacioIdentificador informacioIdentificador;

	private String dir3personaJuridica;

	private String raoSocial;

	private String nomSentit;

	private String nom;
	
	private String cognom1;
	
	private String cognom2;

	private KeyValueTranslator genere;

	private String sexe;

	private String codiMunicipi;

	private String municipi;

	private String codiProvincia;
	
	private String provincia;

	private String codiComunitatAutonoma;
	
	private String comunitatAutonoma;

	private String codiPais;
	
	private String pais;

	private String adressaCompleta;
	
	private KeyValueTranslator tipusVia;
	
	private String nomVia;
	
	private String numeroSuperior;
	
	private String numeroInferior;
	
	private String bloc;
	
	private String portal;

	private String escala;
	
	private String pis;
	
	private String porta;

	private String codiPostal;
	
	private String email;

	private String telefonFix;
	
	private String telefonMobil;
	
	private String fax;
	
	private String adressaElectronicaHabilitada;

	private String canalPreferentComunicacio;
	
	private Boolean consentimentConsulta;
	
	private Boolean consentimentLOPD;
	
	private String nacionalitat;

	private Integer edat;
	
	private String dataNaixement;
	
	private String observacions;


	public KeyValueTranslator getTipusIdentificador() {
		return tipusIdentificador;
	}

	public void setTipusIdentificador(KeyValueTranslator tipusIdentificador) {
		this.tipusIdentificador = tipusIdentificador;
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public InformacioIdentificador getInformacioIdentificador() {
		return informacioIdentificador;
	}

	public void setInformacioIdentificador(InformacioIdentificador informacioIdentificador) {
		this.informacioIdentificador = informacioIdentificador;
	}

	public String getDir3personaJuridica() {
		return dir3personaJuridica;
	}

	public void setDir3personaJuridica(String dir3personaJuridica) {
		this.dir3personaJuridica = dir3personaJuridica;
	}

	public String getRaoSocial() {
		return raoSocial;
	}

	public void setRaoSocial(String raoSocial) {
		this.raoSocial = raoSocial;
	}

	public String getNomSentit() {
		return nomSentit;
	}

	public void setNomSentit(String nomSentit) {
		this.nomSentit = nomSentit;
	}
	
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getCognom1() {
		return cognom1;
	}

	public void setCognom1(String cognom1) {
		this.cognom1 = cognom1;
	}

	public String getCognom2() {
		return cognom2;
	}

	public void setCognom2(String cognom2) {
		this.cognom2 = cognom2;
	}

	public KeyValueTranslator getGenere() {
		return genere;
	}

	public void setGenere(KeyValueTranslator genere) {
		this.genere = genere;
	}

	public String getSexe(){
		return this.sexe;
	}
	
	public void setSexe(String sexe){
		this.sexe = sexe;
	}

	public String getCodiMunicipi() {
		return codiMunicipi;
	}

	public void setCodiMunicipi(String codiMunicipi) {
		this.codiMunicipi = codiMunicipi;
	}

	public String getMunicipi() {
		return municipi;
	}

	public void setMunicipi(String municipi) {
		this.municipi = municipi;
	}

	public String getCodiProvincia() {
		return codiProvincia;
	}

	public void setCodiProvincia(String codiProvincia) {
		this.codiProvincia = codiProvincia;
	}
	
	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getCodiComunitatAutonoma() {
		return codiComunitatAutonoma;
	}

	public void setCodiComunitatAutonoma(String codiComunitatAutonoma) {
		this.codiComunitatAutonoma = codiComunitatAutonoma;
	}

	public String getComunitatAutonoma() {
		return comunitatAutonoma;
	}

	public void setComunitatAutonoma(String comunitatAutonoma) {
		this.comunitatAutonoma = comunitatAutonoma;
	}

	public String getCodiPais() {
		return codiPais;
	}

	public void setCodiPais(String codiPais) {
		this.codiPais = codiPais;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getAdressaCompleta() {
		return adressaCompleta;
	}

	public void setAdressaCompleta(String adressaCompleta) {
		this.adressaCompleta = adressaCompleta;
	}

	public KeyValueTranslator getTipusVia() {
		return tipusVia;
	}

	public void setTipusVia(KeyValueTranslator tipusVia) {
		this.tipusVia = tipusVia;
	}

	public String getNomVia() {
		return nomVia;
	}

	public void setNomVia(String nomVia) {
		this.nomVia = nomVia;
	}

	public String getNumeroSuperior() {
		return numeroSuperior;
	}

	public void setNumeroSuperior(String numeroSuperior) {
		this.numeroSuperior = numeroSuperior;
	}

	public String getNumeroInferior() {
		return numeroInferior;
	}

	public void setNumeroInferior(String numeroInferior) {
		this.numeroInferior = numeroInferior;
	}

	public String getBloc() {
		return bloc;
	}

	public void setBloc(String bloc) {
		this.bloc = bloc;
	}

	public String getPortal() {
		return portal;
	}

	public void setPortal(String portal) {
		this.portal = portal;
	}
	
	public String getEscala() {
		return escala;
	}

	public void setEscala(String escala) {
		this.escala = escala;
	}

	public String getPis() {
		return pis;
	}

	public void setPis(String pis) {
		this.pis = pis;
	}

	public String getPorta() {
		return porta;
	}

	public void setPorta(String porta) {
		this.porta = porta;
	}

	public String getCodiPostal() {
		return codiPostal;
	}

	public void setCodiPostal(String codiPostal) {
		this.codiPostal = codiPostal;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefonFix() {
		return telefonFix;
	}

	public void setTelefonFix(String telefonFix) {
		this.telefonFix = telefonFix;
	}

	public String getTelefonMobil() {
		return telefonMobil;
	}

	public void setTelefonMobil(String telefonMobil) {
		this.telefonMobil = telefonMobil;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}
	
	public String getAdressaElectronicaHabilitada() {
		return adressaElectronicaHabilitada;
	}

	public void setAdressaElectronicaHabilitada(String adressaElectronicaHabilitada) {
		this.adressaElectronicaHabilitada = adressaElectronicaHabilitada;
	}

	public String getCanalPreferentComunicacio() {
		return canalPreferentComunicacio;
	}

	public void setCanalPreferentComunicacio(String canalPreferentComunicacio) {
		this.canalPreferentComunicacio = canalPreferentComunicacio;
	}

	public Boolean getConsentimentConsulta(){
		return this.consentimentConsulta;
	}

	public void setConsentimentConsulta(Boolean consentimentConsulta){
		this.consentimentConsulta = consentimentConsulta;
	}

	public Boolean getConsentimentLOPD(){
		return this.consentimentLOPD;
	}

	public void setConsentimentLOPD(Boolean consentimentLOPD){
		this.consentimentLOPD = consentimentLOPD;
	}

	public String getNacionalitat(){
		return this.nacionalitat;
	}

	public void setNacionalitat(String nacionalitat){
		this.nacionalitat = nacionalitat;
	}

	public Integer getEdat(){
		return this.edat;
	}

	public void setEdat(Integer edat){
		this.edat = edat;
	}

	public String getDataNaixement(){
		return this.dataNaixement;
	}

	public void setDataNaixement(String dataNaixement){
		this.dataNaixement = dataNaixement;
	}

	public String getObservacions() {
		return observacions;
	}

	public void setObservacions(String observacions) {
		this.observacions = observacions;
	}
}
