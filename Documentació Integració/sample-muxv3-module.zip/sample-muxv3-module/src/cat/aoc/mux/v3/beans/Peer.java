package cat.aoc.mux.v3.beans;

import java.io.Serializable;

import cat.aoc.serveis.organismes.beans.OficinaRegistreDir3;
import cat.aoc.serveis.organismes.beans.UnitatOrganicaDir3;


public abstract class Peer implements Serializable {

    private static final long serialVersionUID = 5227353570758217695L;

    private UnitatOrganicaDir3 unitatOrganica;

    private UnitatTramitadora unitatTramitadora;
    
    private OficinaRegistreDir3 oficinaRegistre;

    private Sarcat sarcat;


    public UnitatOrganicaDir3 getUnitatOrganica() {
        return unitatOrganica;
    }

	public UnitatOrganicaDir3 setUnitatOrganica(UnitatOrganicaDir3 unitatOrganica) {
		return this.unitatOrganica = unitatOrganica;
    }

	public UnitatTramitadora getUnitatTramitadora() {
		return unitatTramitadora;
	}

	public void setUnitatTramitadora(UnitatTramitadora unitatTramitadora) {
		this.unitatTramitadora = unitatTramitadora;
	}

	public OficinaRegistreDir3 getOficinaRegistre() {
        return oficinaRegistre;
    }

	public OficinaRegistreDir3 setOficinaRegistre(OficinaRegistreDir3 oficinaRegistre) {
		return this.oficinaRegistre = oficinaRegistre;
    }

    public Sarcat getSarcat() {
        return sarcat;
    }

	public Sarcat setSarcat(Sarcat sarcat) {
		return this.sarcat = sarcat;
    }
}
