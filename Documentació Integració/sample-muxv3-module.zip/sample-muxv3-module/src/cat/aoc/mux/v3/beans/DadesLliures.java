package cat.aoc.mux.v3.beans;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class DadesLliures extends HashMap<String, Object>{


	private static final long serialVersionUID = -7589772370640349738L;
	
	public static final String NOT_A_MAP = "Aquest camp no conté cap diccionari";
	

	public void set(String clau, Object valor){
		super.put(clau, valor);
	}
	
	public Object get(String clau){
		return super.get(clau);
	}
	
	public void setMap(String clau){
		super.put(clau, new HashMap<String, Object>());
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getMap(String clau) throws IllegalStateException{
		Object map = super.get(clau);
		if(map==null){
			map = new HashMap<String, Object>();
			super.put(clau, map);
		}
		if(!(map instanceof Map)){
			throw new IllegalStateException(NOT_A_MAP);
		}
		return (Map<String, Object>)map;
	}
}
