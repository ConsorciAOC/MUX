package cat.aoc.mux.v3.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Transaccio implements Serializable{


	private static final long serialVersionUID = -3827122277647463701L;

	private String idTransaccio;
	
	private Integer execucions;
	
	private TipusTransaccio tipus;
    
	private Date dataCreacio;
	
	private Date dataDarreraExecucio;
	
	private Integer TTL;
    
	private Control control;
	
	private Assumpte assumpte;
	
	private Procediment procediment;

	private Registres registres;
	
	private List<Interessat> interessats;

	private Documents documents;
	
	private Assentaments assentaments;
	
	private InstanciaGenerica instanciaGenerica;
	
	private DadesLliures dadesLliures;

	private Rebuts rebuts;


	public String getIdTransaccio() {
		return idTransaccio;
	}

	public void setIdTransaccio(String idTransaccio) {
		this.idTransaccio = idTransaccio;
	}

	public Integer getExecucions() {
		return execucions;
	}

	public void setExecucions(Integer execucions) {
		this.execucions = execucions;
	}

	public TipusTransaccio getTipus() {
		return tipus;
	}

	public void setTipus(TipusTransaccio tipus) {
		this.tipus = tipus;
	}

	public Date getDataCreacio() {
		return dataCreacio;
	}

	public void setDataCreacio(Date dataCreacio) {
		this.dataCreacio = dataCreacio;
	}

	public Date getDataDarreraExecucio() {
		return dataDarreraExecucio;
	}

	public void setDataDarreraExecucio(Date dataDarreraExecucio) {
		this.dataDarreraExecucio = dataDarreraExecucio;
	}

	public Integer getTTL() {
		return TTL;
	}

	public void setTTL(Integer TTL) {
		this.TTL = TTL;
	}
	
	public Control getControl() {
		return control;
	}

	public Control setControl(Control control) {
		return this.control = control;
	}

	public Assumpte getAssumpte() {
		return assumpte;
	}

	public Assumpte setAssumpte(Assumpte assumpte) {
		return this.assumpte = assumpte;
	}

	public Procediment getProcediment() {
		return procediment;
	}

	public Procediment setProcediment(Procediment procediment) {
		return this.procediment = procediment;
	}
	
	public Registres getRegistres() {
		return registres;
	}

	public Registres setRegistres(Registres registres) {
		return this.registres = registres;
	}

	public List<Interessat> getInteressats() {
		if(this.interessats==null){
			this.interessats = new ArrayList<>();
		}
		return interessats;
	}

	public List<Interessat> setInteressats(List<Interessat> interessats) {
		return this.interessats = interessats;
	}

	public Documents getDocuments() {
		if(this.documents==null){
			this.documents = new Documents();
		}
		return documents;
	}

	public void setDocuments(Documents documents) {
		this.documents = documents;
	}

	public Assentaments getAssentaments() {
		if(this.assentaments==null){
			this.assentaments = new Assentaments();
		}
		return assentaments;
	}

	public Assentaments setAssentaments(Assentaments assentaments) {
		return this.assentaments = assentaments;
	}

	public InstanciaGenerica getInstanciaGenerica() {
		return instanciaGenerica;
	}

	public InstanciaGenerica setInstanciaGenerica(InstanciaGenerica instanciaGenerica) {
		return this.instanciaGenerica = instanciaGenerica;
	}

	public DadesLliures getDadesLliures() {
		return dadesLliures;
	}

	public DadesLliures setDadesLliures(DadesLliures dadesLliures) {
		return this.dadesLliures = dadesLliures;
	}
	
	public Rebuts getRebuts() {
		return rebuts;
	}

	public void setRebuts(Rebuts rebuts) {
		this.rebuts = rebuts;
	}
}