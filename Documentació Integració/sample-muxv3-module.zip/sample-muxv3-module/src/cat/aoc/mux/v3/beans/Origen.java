package cat.aoc.mux.v3.beans;

public class Origen extends Peer {

    private static final long serialVersionUID = 8807081977899160732L;

}
