package cat.aoc.mux.v3.registres.beans;

import java.io.Serializable;

public class RespostaRegistre implements Serializable {

	private static final long serialVersionUID = 481959314578989586L;

	private Boolean resultat;
	
	private Integer codiError;

	private String missatgeError;
	
	private String idTransaccio;
	
	private String tipus;

	private String numeroAssentament;

	private String dataAssentament;

	private String dataPresentacio;


	public Boolean getResultat() {
		return resultat;
	}

	public void setResultat(Boolean resultat) {
		this.resultat = resultat;
	}

	public Integer getCodiError() {
		return codiError;
	}

	public void setCodiError(Integer codiError) {
		this.codiError = codiError;
	}

	public String getMissatgeError() {
		return missatgeError;
	}

	public void setMissatgeError(String missatgeError) {
		this.missatgeError = missatgeError;
	}

	public String getIdTransaccio() {
		return idTransaccio;
	}

	public void setIdTransaccio(String idTransaccio) {
		this.idTransaccio = idTransaccio;
	}

	public String getTipus() {
		return tipus;
	}

	public void setTipus(String tipus) {
		this.tipus = tipus;
	}

	public String getNumeroAssentament() {
		return numeroAssentament;
	}

	public void setNumeroAssentament(String numeroAssentament) {
		this.numeroAssentament = numeroAssentament;
	}

	public String getDataAssentament() {
		return dataAssentament;
	}

	public void setDataAssentament(String dataAssentament) {
		this.dataAssentament = dataAssentament;
	}

	public String getDataPresentacio() {
		return dataPresentacio;
	}

	public void setDataPresentacio(String dataPresentacio) {
		this.dataPresentacio = dataPresentacio;
	}
}
