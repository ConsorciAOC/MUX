package cat.aoc.mux.v3.beans;

import java.io.Serializable;
import java.util.Map;


public class Assentament implements Serializable {


	private static final long serialVersionUID = 5128230187911503094L;

	private long creation;
	
	private Integer execucio;
	
	private Boolean resultat;

	private int codiError;

	private String missatgeError;

	private String nomReglaEnrutament;
	
	private String nomRegistre;

	private String idBustia;

	private String numeroAssentament;

	private String dataAssentament;

	private String dataPresentacio;

	private Evidencies evidencies;


	public long getCreation() {
		return creation;
	}

	public void setCreation(long creation) {
		this.creation = creation;
	}

	public Integer getExecucio() {
		return execucio;
	}

	public void setExecucio(Integer execucio) {
		this.execucio = execucio;
	}

	public Boolean getResultat() {
		return resultat;
	}

	public void setResultat(Boolean resultat) {
		this.resultat = resultat;
	}

	public int getCodiError() {
		return codiError;
	}

	public void setCodiError(int codiError) {
		this.codiError = codiError;
	}

	public String getMissatgeError() {
		return missatgeError;
	}

	public void setMissatgeError(String missatgeError) {
		this.missatgeError = missatgeError;
	}

	public String getNomReglaEnrutament() {
		return nomReglaEnrutament;
	}

	public void setNomReglaEnrutament(String nomReglaEnrutament) {
		this.nomReglaEnrutament = nomReglaEnrutament;
	}

	public String getNomRegistre() {
		return nomRegistre;
	}

	public void setNomRegistre(String nomRegistre) {
		this.nomRegistre = nomRegistre;
	}

	public String getIdBustia() {
		return idBustia;
	}

	public void setIdBustia(String idBustia) {
		this.idBustia = idBustia;
	}
	
	public String getNumeroAssentament() {
		return numeroAssentament;
	}

	public void setNumeroAssentament(String numeroAssentament) {
		this.numeroAssentament = numeroAssentament;
	}

	public String getDataAssentament() {
		return dataAssentament;
	}

	public void setDataAssentament(String dataAssentament) {
		this.dataAssentament = dataAssentament;
	}

	public String getDataPresentacio() {
		return dataPresentacio;
	}

	public void setDataPresentacio(String dataPresentacio) {
		this.dataPresentacio = dataPresentacio;
	}

	public Evidencies getEvidencies(){
		if(this.evidencies==null){
			this.evidencies = new Evidencies();
		}
		return this.evidencies;
	}

	public Evidencies setEvidencies(Evidencies evidencies){
		return this.evidencies = evidencies;
	}

	public void addEvidencia(String authorization, byte[] request, Map<String, String> responseHeaders, byte[] response, boolean connectTimedOut, boolean readTimedOut, int elapsedTime){
		if(this.evidencies==null){
			this.evidencies = new Evidencies();
		}
		this.evidencies.push(authorization, request, responseHeaders, response, connectTimedOut, readTimedOut, elapsedTime);
	}
}
