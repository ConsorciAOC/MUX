package cat.aoc.mux.v3.beans;

import java.io.Serializable;


public class Sarcat implements Serializable {

	private static final long serialVersionUID = -2226617649821143013L;

	private String urPK;

	private Integer idCentreProcedencia;

	private Integer idCentreDestinacio;

	private Integer idCentreDestinacioInterna;

	private Integer idCentreDestinacioExterna;


	public String getUrPK() {
		return urPK;
	}

	public void setUrPK(String urPK) {
		this.urPK = urPK;
	}

	public Integer getIdCentreProcedencia() {
		return idCentreProcedencia;
	}

	public void setIdCentreProcedencia(Integer idCentreProcedencia) {
		this.idCentreProcedencia = idCentreProcedencia;
	}

	public Integer getIdCentreDestinacio() {
		return idCentreDestinacio;
	}

	public void setIdCentreDestinacio(Integer idCentreDestinacio) {
		this.idCentreDestinacio = idCentreDestinacio;
	}

	public Integer getIdCentreDestinacioInterna() {
		return idCentreDestinacioInterna;
	}

	public void setIdCentreDestinacioInterna(Integer idCentreDestinacioInterna) {
		this.idCentreDestinacioInterna = idCentreDestinacioInterna;
	}

	public Integer getIdCentreDestinacioExterna() {
		return idCentreDestinacioExterna;
	}

	public void setIdCentreDestinacioExterna(Integer idCentreDestinacioExterna) {
		this.idCentreDestinacioExterna = idCentreDestinacioExterna;
	}
}
