package cat.aoc.mux.v3.beans;

import java.io.Serializable;

public class Rebuts implements Serializable{

	private static final long serialVersionUID = -5913172318002872906L;

	private String nomRebutEntrada;
	
	private String rebutEntrada;
	
	private String nomRebutSortida;
	
	private String rebutSortida;


	public Rebuts(){
		this.rebutEntrada = null;
		this.rebutSortida = null;
	}

	public Rebuts(String rebutEntrada, String rebutSortida){
		this.rebutEntrada = rebutEntrada;
		this.rebutSortida = rebutSortida;
	}
	

	public String getNomRebutEntrada() {
		return nomRebutEntrada;
	}

	public void setNomRebutEntrada(String nomRebutEntrada) {
		this.nomRebutEntrada = nomRebutEntrada;
	}

	public String getRebutEntrada() {
		return rebutEntrada;
	}

	public void setRebutEntrada(String rebutEntrada) {
		this.rebutEntrada = rebutEntrada;
	}

	public String getNomRebutSortida() {
		return nomRebutSortida;
	}

	public void setNomRebutSortida(String nomRebutSortida) {
		this.nomRebutSortida = nomRebutSortida;
	}

	public String getRebutSortida() {
		return rebutSortida;
	}

	public void setRebutSortida(String rebutSortida) {
		this.rebutSortida = rebutSortida;
	}
}
