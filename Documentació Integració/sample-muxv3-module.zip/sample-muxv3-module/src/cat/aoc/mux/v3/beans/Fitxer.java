package cat.aoc.mux.v3.beans;

import java.io.InputStream;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class Fitxer implements Serializable {


	private static final long serialVersionUID = -2040888895551587567L;

	private String uuid;
	
	private byte[] sha256;
	
	private transient Long tamany;

	private String fileName;
	
	private String mimeType;

	private transient InputStream inputStream;


	public String getUUID(){
		return this.uuid;
	}

	public void setUUID(String uuid){
		this.uuid = uuid;
	}

	@JsonIgnore
	public byte[] getSha256(){
		return this.sha256;
	}

	public void setSha256(byte[] sha256){
		this.sha256 = sha256;
	}

	@JsonIgnore
	public Long getTamany(){
		return this.tamany;
	}

	public void setTamany(Long tamany){
		this.tamany = tamany;
	}

	@JsonIgnore
	public String getFileName(){
		return this.fileName;
	}

	public void setFileName(String fileName){
		this.fileName = fileName;
	}
	
	@JsonIgnore
	public String getMIMEType(){
		return this.mimeType;
	}

	public void setMIMEType(String mimeType){
		this.mimeType = mimeType;
	}
	
	@JsonIgnore
	public InputStream getInputStream(){
		return this.inputStream;
	}

	public void setInputStream(InputStream inputStream){
		this.inputStream = inputStream;
	}
}
