package cat.aoc.mux.v3.beans;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class Assumpte implements Serializable {


	private static final long serialVersionUID = -8249917686336905289L;

	private String resum;
	
	private String observacions;

	private Date dataPresentacio;

	private String codiAssumpteSegonsDesti;
	
	private String referenciaExterna;
	
	private String numeroExpedient;
	
	private String numeroExpedientSegonsDesti;
	
	private String codiFamilia;
	
	private String nomFamilia;
	
	private String codiProcediment;
	
	private String nomProcediment;
	
	private String codiSIA;
	
	private String nomSIA;
	
	private String codiTramit;
	
	private String nomTramit;

	
	public String getResum() {
		return resum;
	}

	public void setResum(String resum) {
		this.resum = resum;
	}

	public String getObservacions() {
		return observacions;
	}

	public void setObservacions(String observacions) {
		this.observacions = observacions;
	}

	public Date getDataPresentacio() {
		return dataPresentacio;
	}

	public void setDataPresentacio(Date dataPresentacio) {
		this.dataPresentacio = dataPresentacio;
	}

	public String getCodiAssumpteSegonsDesti() {
		return codiAssumpteSegonsDesti;
	}

	public void setCodiAssumpteSegonsDesti(String codiAssumpteSegonsDesti) {
		this.codiAssumpteSegonsDesti = codiAssumpteSegonsDesti;
	}

	public String getReferenciaExterna() {
		return referenciaExterna;
	}

	public void setReferenciaExterna(String referenciaExterna) {
		this.referenciaExterna = referenciaExterna;
	}

	public String getNumeroExpedient() {
		return numeroExpedient;
	}

	public void setNumeroExpedient(String numeroExpedient) {
		this.numeroExpedient = numeroExpedient;
	}

	public String getNumeroExpedientSegonsDesti() {
		return numeroExpedientSegonsDesti;
	}

	public void setNumeroExpedientSegonsDesti(String numeroExpedientSegonsDesti) {
		this.numeroExpedientSegonsDesti = numeroExpedientSegonsDesti;
	}

	public String getCodiFamilia() {
		return codiFamilia;
	}

	public void setCodiFamilia(String codiFamilia) {
		this.codiFamilia = codiFamilia;
	}

	public String getNomFamilia() {
		return nomFamilia;
	}

	public void setNomFamilia(String nomFamilia) {
		this.nomFamilia = nomFamilia;
	}

	public String getCodiProcediment() {
		return codiProcediment;
	}

	public void setCodiProcediment(String codiProcediment) {
		this.codiProcediment = codiProcediment;
	}

	public String getNomProcediment() {
		return nomProcediment;
	}

	public void setNomProcediment(String nomProcediment) {
		this.nomProcediment = nomProcediment;
	}

	public String getCodiSIA() {
		return codiSIA;
	}

	public void setCodiSIA(String codiSIA) {
		this.codiSIA = codiSIA;
	}

	public String getNomSIA() {
		return nomSIA;
	}

	public void setNomSIA(String nomSIA) {
		this.nomSIA = nomSIA;
	}

	public String getCodiTramit() {
		return codiTramit;
	}

	public void setCodiTramit(String codiTramit) {
		this.codiTramit = codiTramit;
	}

	public String getNomTramit() {
		return nomTramit;
	}

	public void setNomTramit(String nomTramit) {
		this.nomTramit = nomTramit;
	}
}
