package cat.aoc.mux.v3.beans;

import java.io.Serializable;


public class InformacioIdentificador implements Serializable{

	private static final long serialVersionUID = 8403146373696790522L;

	public enum TipusIdentificadors {DNI, NIF, NIE, VAT};

	public enum TipusPersona {F, J};

	private boolean valid;

	private TipusIdentificadors tipusIdentificador;

	private TipusPersona tipusPersona;

	private String tipusEntitat;

	private String identificador;
	
	private String provincia;
	
	private String observacions;
	

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}

	public TipusIdentificadors getTipusIdentificador() {
		return tipusIdentificador;
	}

	public void setTipusIdentificador(TipusIdentificadors tipusIdentificador) {
		this.tipusIdentificador = tipusIdentificador;
	}

	public TipusPersona getTipusPersona() {
		return tipusPersona;
	}

	public void setTipusPersona(TipusPersona tipusPersona) {
		this.tipusPersona = tipusPersona;
	}

	public String getTipusEntitat() {
		return tipusEntitat;
	}

	public void setTipusEntitat(String tipusEntitat) {
		this.tipusEntitat = tipusEntitat;
	}
	
	public String getIdentificador() {
		return this.identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public String getProvincia() {
		return this.provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getObservacions() {
		return this.observacions;
	}

	public void setObservacions(String observacions) {
		this.observacions = observacions;
	}
}
