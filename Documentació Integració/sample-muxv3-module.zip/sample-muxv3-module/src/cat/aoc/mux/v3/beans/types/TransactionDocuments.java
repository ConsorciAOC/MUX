package cat.aoc.mux.v3.beans.types;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

import cat.aoc.mux.v3.beans.Document;
import cat.aoc.mux.v3.beans.TipusTransaccio;
import cat.aoc.mux.v3.beans.Transaccio;

public class TransactionDocuments extends LinkedHashMap<String, Document> implements Serializable, Cloneable {

	private static final long serialVersionUID = 6097341860675016276L;

	private String idTransaccio;

	private TipusTransaccio tipus;


	public TransactionDocuments(){}

	public TransactionDocuments(String idTransaccio, TipusTransaccio tipus){
		this.idTransaccio = idTransaccio;
		this.tipus = tipus;
	}

	public TransactionDocuments(String idTransaccio, TipusTransaccio tipus, Map<String, Document> documents){
		this.idTransaccio = idTransaccio;
		this.tipus = tipus;
		this.putAll(documents);
	}

	public String getIdTransaccio() {
		return idTransaccio;
	}

	public void setIdTransaccio(String idTransaccio) {
		this.idTransaccio = idTransaccio;
	}

	public TipusTransaccio getTipus() {
		return tipus;
	}

	public void setTipus(TipusTransaccio tipus) {
		this.tipus = tipus;
	}

	@Override
	public TransactionDocuments clone(){
		TransactionDocuments td = new TransactionDocuments();
		td.setIdTransaccio(this.idTransaccio);
		td.setTipus(this.tipus);
		td.putAll(this);
		return td;
	}

	public static TransactionDocuments fromTransaccio(Transaccio transaccio){
		return new TransactionDocuments(transaccio.getIdTransaccio(), transaccio.getTipus(), transaccio.getDocuments());
		
	}
}

