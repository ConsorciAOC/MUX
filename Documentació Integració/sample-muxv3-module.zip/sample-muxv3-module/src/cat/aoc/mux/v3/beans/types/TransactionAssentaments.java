package cat.aoc.mux.v3.beans.types;

import java.io.Serializable;

import cat.aoc.mux.v3.beans.Assentaments;
import cat.aoc.mux.v3.beans.TipusTransaccio;
import cat.aoc.mux.v3.beans.Transaccio;

public class TransactionAssentaments extends Assentaments implements Serializable, Cloneable {

	private static final long serialVersionUID = 6097341860675016276L;

	private String idTransaccio;

	private TipusTransaccio tipus;


	public TransactionAssentaments(){}

	public TransactionAssentaments(String idTransaccio, TipusTransaccio tipus){
		this.idTransaccio = idTransaccio;
		this.tipus = tipus;
		super.setSortida(null);
		super.setEntrada(null);
	}

	public TransactionAssentaments(String idTransaccio, TipusTransaccio tipus, Assentaments assentaments){
		this.idTransaccio = idTransaccio;
		this.tipus = tipus;
		if(assentaments!=null) {
			super.setSortida(assentaments.getSortida());
			super.setEntrada(assentaments.getEntrada());
		}
	}

	public String getIdTransaccio() {
		return idTransaccio;
	}

	public void setIdTransaccio(String idTransaccio) {
		this.idTransaccio = idTransaccio;
	}

	public TipusTransaccio getTipus() {
		return tipus;
	}

	public void setTipus(TipusTransaccio tipus) {
		this.tipus = tipus;
	}

	@Override
	public TransactionAssentaments clone(){
		TransactionAssentaments td = new TransactionAssentaments();
		td.setIdTransaccio(this.idTransaccio);
		td.setTipus(this.tipus);
		td.setEntrada(super.getEntrada());
		td.setSortida(super.getSortida());
		return td;
	}

	public static TransactionAssentaments fromTransaccio(Transaccio transaccio){
		return new TransactionAssentaments(transaccio.getIdTransaccio(), transaccio.getTipus(), transaccio.getAssentaments());
	}

	public static Assentaments toAssentaments(TransactionAssentaments transactionAssentaments){
		Assentaments assentaments = new Assentaments();
		if(transactionAssentaments!=null){
			assentaments.setEntrada(transactionAssentaments.getEntrada());
			assentaments.setSortida(transactionAssentaments.getSortida());
		}
		return assentaments;
	}

}

