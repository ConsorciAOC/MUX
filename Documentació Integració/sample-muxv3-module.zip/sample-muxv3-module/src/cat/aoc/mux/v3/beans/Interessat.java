package cat.aoc.mux.v3.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class Interessat extends Persona{


	private static final long serialVersionUID = 5175124209381138447L;

	private Representant representant;


	public Representant getRepresentant() {
		return representant;
	}

	public Representant setRepresentant(Representant representant) {
		return this.representant = representant;
	}
}
