package cat.aoc.mux.v3.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import cat.aoc.mux.v3.beans.types.KeyValueTranslator;


@JsonInclude(Include.NON_NULL)
public class Procediment implements Serializable {


	private static final long serialVersionUID = -8249917686336905289L;

	private String identificadorResolutor;				// eEMC_Exp_IdentificadorResolutor
	
	private String nomResolutor;						// eEMC_Exp_NombreResolutor
		
	private KeyValueTranslator destinatari;				// eEMC_Proc_Destinatario
	
	private Boolean preuTasa;							// eEMC_Proc_PrecioTasa

	private KeyValueTranslator inici;					// eEMC_Proc_Inicio [De Interessat, D'Ofici]
	
	private KeyValueTranslator efecteSilenci;			// eEMC_Proc_EfectoSilencio [Positiu, Negatiu, Caducitat, No te, Segons normativa aplicable]
	
	private KeyValueTranslator tipusProcediment;		// eEMC_Proc_TipoProcedimiento [Extern Espec�fic, Intern Espec�fic, Extern Com�, Intern Com�]
	
	private Boolean fiViaAdministrativa;				// eEMC_Proc_FinViaAdministrativa
	
	private KeyValueTranslator rangNormativa;			// eEMC_Proc_Normativa.Rango [NORMA CONSTITUCIONAL, TRATADO Y ACUERDO INTERNACIONAL, DIRECTIVA, REGLAMENTO UE, DECISI�N, LEY ORG�NICA, LEY, REAL DECRETO LEGISLATIVO, REAL DECRETO LEY, REAL DECRETO, ORDEN, RESOLUCI�N, INSTRUCCI�N, CIRCULAR, ACUERDO, ORDENANZA,	SENTENCIA, OTRAS DISPOSICIONES,	DECRETO, OTROS,	LEY FORAL, DECRETO LEGISLATIVO, DECRETO FORAL, DECRETO-LEY]
	
	private String numeroDisposicio;					// eEMC_Proc_Normativa.N�meroDisposici�n
	
	private String titolNormativa;						// eEMC_Proc_Normativa.T�tulo
	
	private KeyValueTranslator materia;					// eEMC_Proc_Materia [Acci�n exterior, Agricultura, Ganader�a; Pesca y Alimentaci�n, Asociaciones, Fundaciones y otras Entidades, Becas, Ayudas y Premios,	Consumo, Cultura, Deportes, Comunicaci�n, Ciudadan�a y nacionalidad, Econom�a y Patrimonio del Estado, Educaci�n y formaci�n, Empleo y Seguridad social, Empresas, Energ�a e Industria, Estad�sticas, Impuestos y otros tributos, Justicia,	Medio Ambiente, Participaci�n e iniciativa ciudadana, Pensiones, Protecci�n Civil, Seguridad Ciudadana y Defensa Nacional, Relaciones con la Administraci�n, Relaciones entre Administraciones P�blicas,	Salud, Servicios Sociales e Igualdad, Tecnolog�a, Investigaci�n  e Innovaci�n, Telecomunicaciones y Sociedad de la Informaci�n, Tr�fico y Transportes, Turismo, ocio y tiempo libre, Vivienda y Urbanismo, Comunicaci�n, Ingresos no tributarios]
	
	private KeyValueTranslator canalAcces;				// eEMC_Proc_CanalesAcceso [PRESENCIAL, ELECTORNIC, CORREU POSTAL, TELEFONIC]
	
	private KeyValueTranslator requisitsIdentificacio;	// eEMC_Proc_RequisitosIdentificaci�n [NO REQUEREIX, CERTIFICAT ELECT, ENTREGA PRESENCIAL, USUARI CONTRASENYA, DNIE, CLAVE PIN]
	
	private String urlAccesFormulari;					// eEMC_Proc_Formulario
	
	private String terminiResolucio;					// eEMC_Proc_PlazoResoluci�n
	
	private KeyValueTranslator viaNotificacio;			// eEMC_Proc_ViaNotificaciones [POSTAL, COMAPRECENCIA EN SEDE, DEH, DEV]


	public String getIdentificadorResolutor() {
		return identificadorResolutor;
	}

	public void setIdentificadorResolutor(String identificadorResolutor) {
		this.identificadorResolutor = identificadorResolutor;
	}

	public String getNomResolutor() {
		return nomResolutor;
	}

	public void setNomResolutor(String nomResolutor) {
		this.nomResolutor = nomResolutor;
	}

	public KeyValueTranslator getDestinatari() {
		return destinatari;
	}

	public void setDestinatari(KeyValueTranslator destinatari) {
		this.destinatari = destinatari;
	}

	public Boolean getPreuTasa() {
		return preuTasa;
	}

	public void setPreuTasa(Boolean preuTasa) {
		this.preuTasa = preuTasa;
	}

	public KeyValueTranslator getInici() {
		return inici;
	}

	public void setInici(KeyValueTranslator inici) {
		this.inici = inici;
	}

	public KeyValueTranslator getEfecteSilenci() {
		return efecteSilenci;
	}

	public void setEfecteSilenci(KeyValueTranslator efecteSilenci) {
		this.efecteSilenci = efecteSilenci;
	}

	public KeyValueTranslator getTipusProcediment() {
		return tipusProcediment;
	}

	public void setTipusProcediment(KeyValueTranslator tipusProcediment) {
		this.tipusProcediment = tipusProcediment;
	}

	public Boolean getFiViaAdministrativa() {
		return fiViaAdministrativa;
	}

	public void setFiViaAdministrativa(Boolean fiViaAdministrativa) {
		this.fiViaAdministrativa = fiViaAdministrativa;
	}

	public KeyValueTranslator getRangNormativa() {
		return rangNormativa;
	}

	public void setRangNormativa(KeyValueTranslator rangNormativa) {
		this.rangNormativa = rangNormativa;
	}

	public String getNumeroDisposicio() {
		return numeroDisposicio;
	}

	public void setNumeroDisposicio(String numeroDisposicio) {
		this.numeroDisposicio = numeroDisposicio;
	}

	public String getTitolNormativa() {
		return titolNormativa;
	}

	public void setTitolNormativa(String titolNormativa) {
		this.titolNormativa = titolNormativa;
	}

	public KeyValueTranslator getMateria() {
		return materia;
	}

	public void setMateria(KeyValueTranslator materia) {
		this.materia = materia;
	}

	public KeyValueTranslator getCanalAcces() {
		return canalAcces;
	}

	public void setCanalAcces(KeyValueTranslator canalAcces) {
		this.canalAcces = canalAcces;
	}

	public KeyValueTranslator getRequisitsIdentificacio() {
		return requisitsIdentificacio;
	}

	public void setRequisitsIdentificacio(KeyValueTranslator requisitsIdentificacio) {
		this.requisitsIdentificacio = requisitsIdentificacio;
	}

	public String getUrlAccesFormulari() {
		return urlAccesFormulari;
	}

	public void setUrlAccesFormulari(String urlAccesFormulari) {
		this.urlAccesFormulari = urlAccesFormulari;
	}

	public String getTerminiResolucio() {
		return terminiResolucio;
	}

	public void setTerminiResolucio(String terminiResolucio) {
		this.terminiResolucio = terminiResolucio;
	}

	public KeyValueTranslator getViaNotificacio() {
		return viaNotificacio;
	}

	public void setViaNotificacio(KeyValueTranslator viaNotificacio) {
		this.viaNotificacio = viaNotificacio;
	}
}
