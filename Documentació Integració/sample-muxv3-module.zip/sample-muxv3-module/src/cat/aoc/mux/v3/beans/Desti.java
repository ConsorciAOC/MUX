package cat.aoc.mux.v3.beans;

public class Desti extends Peer {

    private static final long serialVersionUID = -7934692353316153580L;

}
