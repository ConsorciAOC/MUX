package cat.aoc.mux.v3.beans.types;

import java.io.Serializable;


public class KeyValueTranslator implements Serializable {


	private static final long serialVersionUID = 4063511557038392312L;

	private String clau;

	private String nti;
	
	private String muxv2;
	
	private String sarcatEntrada;
	
	private String sarcatSortida;

	private String eres;
	
	private String eacat;
	
	private String descripcio;


	public KeyValueTranslator(){
		this.clau = null;
		this.nti = null;
		this.muxv2 = null;
		this.sarcatEntrada = null;
		this.sarcatSortida = null;
		this.eres = null;
		this.eacat = null;
		this.descripcio = null;
	}

	public KeyValueTranslator(String clau){
		this.clau = clau;
		this.nti = null;
		this.muxv2 = null;
		this.sarcatEntrada = null;
		this.sarcatSortida = null;
		this.eres = null;
		this.eacat = null;
		this.descripcio = null;
	}

	public KeyValueTranslator(String clau, String descripcio){
		this.clau = clau;
		this.nti = null;
		this.muxv2 = null;
		this.sarcatEntrada = null;
		this.sarcatSortida = null;
		this.eres = null;
		this.eacat = null;
		this.descripcio = descripcio;
	}

	public KeyValueTranslator(String clau, String nti, String muxv2, String sarcatEntrada, String sarcatSortida, String eres, String eacat, String descripcio){
		this.clau = clau;
		this.nti = nti;
		this.muxv2 = muxv2;
		this.sarcatEntrada = sarcatEntrada;
		this.sarcatSortida = sarcatSortida;
		this.eres = eres;
		this.eacat = eacat;
		this.descripcio = descripcio;
	}

	public void setClau(String key){
		this.clau = key;
	}

	public String getClau(){
		return this.clau;
	}

	public void setNTI(String nti){
		this.nti = nti;
	}

	public String getNTI(){
		return this.nti;
	}
	
	public String getMuxv2() {
		return muxv2;
	}

	public void setMuxv2(String muxv2) {
		this.muxv2 = muxv2;
	}

	public String getSarcatEntrada() {
		return sarcatEntrada;
	}

	public void setSarcatEntrada(String sarcatEntrada) {
		this.sarcatEntrada = sarcatEntrada;
	}

	public String getSarcatSortida() {
		return sarcatSortida;
	}

	public void setSarcatSortida(String sarcatSortida) {
		this.sarcatSortida = sarcatSortida;
	}

	public String getEres() {
		return eres;
	}

	public void setEres(String eres) {
		this.eres = eres;
	}

	public String getEacat() {
		return eacat;
	}

	public void setEacat(String eacat) {
		this.eacat = eacat;
	}

	public void setDescripcio(String description){
		this.descripcio = description;
	}

	public String getDescripcio(){
		return this.descripcio;
	}

	@Override
	public String toString(){
		return this.clau;
	}
}