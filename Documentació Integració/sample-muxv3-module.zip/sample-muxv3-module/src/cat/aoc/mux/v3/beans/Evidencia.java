package cat.aoc.mux.v3.beans;

import java.io.Serializable;
import java.util.Map;


public class Evidencia implements Serializable{

	private static final long serialVersionUID = 1425734153784549893L;

	private long creation;
	
	private String authorization;

	private Map<String, String> responseHeaders;

	private byte[] request;
	
	private byte[] response;
	
	private boolean connectTimedOut;
	
	private boolean readTimedOut;
	
	private int elapsedTime;


	public Evidencia(){
		this.creation = System.currentTimeMillis();
		this.request = null;
		this.responseHeaders = null;
		this.response = null;
		this.connectTimedOut = false;
		this.readTimedOut = false;
		this.elapsedTime = 0;
	}

	public Evidencia(String authorization, byte[] request, Map<String, String> responseHeaders, byte[] response, boolean connectTimedOut, boolean readTimedOut, int elapsedTime){
		this.creation = System.currentTimeMillis() - elapsedTime;
		this.authorization = authorization;
		this.request = request;
		this.responseHeaders = responseHeaders;
		this.response = response;
		this.connectTimedOut = connectTimedOut;
		this.readTimedOut = readTimedOut;
		this.elapsedTime = elapsedTime;
	}

	public long getCreation(){
		return this.creation;
	}

	public byte[] getRequest() {
		return this.request;
	}

	public void setRequest(byte[] request) {
		this.request = request;
	}

	public Map<String, String> getResponseHeaders() {
		return this.responseHeaders;
	}

	public void setResponseHeaders(Map<String, String> responseHeaders) {
		this.responseHeaders = responseHeaders;
	}

	public byte[] getResponse() {
		return this.response;
	}

	public void setResponse(byte[] response) {
		this.response = response;
	}

	public boolean isConnectTimedOut() {
		return this.connectTimedOut;
	}

	public void setConnectTimedOut(boolean connectTimedOut) {
		this.connectTimedOut = connectTimedOut;
	}

	public boolean isReadTimedOut() {
		return this.readTimedOut;
	}

	public void setReadTimedOut(boolean readTimedOut) {
		this.readTimedOut = readTimedOut;
	}
	
	public int getElapsedTime() {
		return this.elapsedTime;
	}

	public void setElapsedTime(int elapsedTime) {
		this.elapsedTime = elapsedTime;
	}

	@Override
	public String toString(){
		return "{\n  creation=" + this.creation + ";\n  elapsedTime=" + this.elapsedTime+ ";\n  connectTimedOut=" + this.connectTimedOut+ ";\n  readTimedOut=" + this.readTimedOut+ ";\n  authorization=" + ((this.authorization!=null)?this.authorization:"") + ";\n  request=" + ((this.request!=null)?new String(this.request).replaceAll("\n|\r", ""):"") + ";\n  response_headers="+this.responseHeaders + ";\n  response=" + ((this.response!=null)?new String(this.response).replaceAll("\n|\r", ""):"") + ";\n}";
	}
}
