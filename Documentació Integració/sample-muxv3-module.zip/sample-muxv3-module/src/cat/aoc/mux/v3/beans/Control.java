package cat.aoc.mux.v3.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import cat.aoc.mux.v3.beans.types.KeyValueTranslator;


@JsonInclude(Include.NON_NULL)
public class Control implements Serializable{

    private static final long serialVersionUID = 1222625348914648496L;
    
    private String aplicacio;
    
    private String urlAplicacio;
    
    private String observacionsApunt;

    private KeyValueTranslator documentacioFisica;
    
    private KeyValueTranslator indicadorProva;
    
    private String usuari;

    private KeyValueTranslator tipusTransport;

    private String numeroTransport;

    private String contacteUsuari;
    
    private String identificadorIntercanvi;

    private String numeroAssentamentIntercanvi;
    
    private KeyValueTranslator tipusAnotacio;


	public String getAplicacio() {
		return aplicacio;
	}

	public void setAplicacio(String aplicacio) {
		this.aplicacio = aplicacio;
	}

	public String getUrlAplicacio() {
		return urlAplicacio;
	}

	public void setUrlAplicacio(String urlAplicacio) {
		this.urlAplicacio = urlAplicacio;
	}

	public String getObservacionsApunt() {
		return observacionsApunt;
	}

	public void setObservacionsApunt(String observacionsApunt) {
		this.observacionsApunt = observacionsApunt;
	}

	public KeyValueTranslator getDocumentacioFisica() {
		return documentacioFisica;
	}

	public void setDocumentacioFisica(KeyValueTranslator documentacioFisica) {
		this.documentacioFisica = documentacioFisica;
	}

	public KeyValueTranslator getIndicadorProva() {
		return indicadorProva;
	}

	public void setIndicadorProva(KeyValueTranslator indicadorProva) {
		this.indicadorProva = indicadorProva;
	}

	public String getUsuari() {
		return usuari;
	}

	public void setUsuari(String usuari) {
		this.usuari = usuari;
	}

	public KeyValueTranslator getTipusTransport() {
		return tipusTransport;
	}

	public void setTipusTransport(KeyValueTranslator tipusTransport) {
		this.tipusTransport = tipusTransport;
	}

	public String getNumeroTransport() {
		return numeroTransport;
	}

	public void setNumeroTransport(String numeroTransport) {
		this.numeroTransport = numeroTransport;
	}

	public String getContacteUsuari() {
		return contacteUsuari;
	}

	public void setContacteUsuari(String contacteUsuari) {
		this.contacteUsuari = contacteUsuari;
	}

	public String getIdentificadorIntercanvi() {
		return identificadorIntercanvi;
	}

	public void setIdentificadorIntercanvi(String identificadorIntercanvi) {
		this.identificadorIntercanvi = identificadorIntercanvi;
	}

	public String getNumeroAssentamentIntercanvi() {
		return numeroAssentamentIntercanvi;
	}

	public void setNumeroAssentamentIntercanvi(String numeroAssentamentIntercanvi) {
		this.numeroAssentamentIntercanvi = numeroAssentamentIntercanvi;
	}

	public KeyValueTranslator getTipusAnotacio() {
		return tipusAnotacio;
	}

	public void setTipusAnotacio(KeyValueTranslator tipusAnotacio) {
		this.tipusAnotacio = tipusAnotacio;
	}
}
