package cat.aoc.mux.v3.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class Sortida extends TriplaAssentaments{

	private static final long serialVersionUID = 3441563915266189601L;

}
