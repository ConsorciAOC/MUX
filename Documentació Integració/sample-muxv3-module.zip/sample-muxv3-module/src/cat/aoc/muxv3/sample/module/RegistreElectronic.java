package cat.aoc.muxv3.sample.module;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.atomic.AtomicInteger;

import cat.aoc.mux.v3.beans.TipusTransaccio;
import cat.aoc.mux.v3.beans.Transaccio;
import cat.aoc.mux.v3.registres.beans.RespostaRegistre;

/**
 * Implementació dummy de registre electrònic
 * 
 * En un cas real, dins d'aquesta classe s'invocaria el WebService del registre electrònic
 */

public class RegistreElectronic {

	private static final AtomicInteger comptadorEntrada = new AtomicInteger(0);

	private static final AtomicInteger comptadorSortida = new AtomicInteger(0);

	private static final SecureRandom random;

	static{
		SecureRandom _random = null;
		try{_random = SecureRandom.getInstance("SHA1PRNG");}catch(Exception ignored){}
		random = _random;
	}


	public static RespostaRegistre invoca(Transaccio transaccio) throws Exception {

		int numeroAleatori = getNumeroAleatori(0, 30);

		Date dataAssentament = GregorianCalendar.getInstance().getTime();
		Date dataPresentacio = transaccio.getAssumpte().getDataPresentacio();
		if(dataPresentacio==null){
			dataPresentacio = GregorianCalendar.getInstance().getTime();
		}

		String numeroAssentament = null;

		if(TipusTransaccio.E==transaccio.getTipus()){
			numeroAssentament = generaNumeroAssentament(transaccio, comptadorEntrada);
		}else if(TipusTransaccio.S==transaccio.getTipus()){
			numeroAssentament = generaNumeroAssentament(transaccio, comptadorSortida);
		}else{
			throw new Exception("Només es suporta la realització d'assentaments d'entrada i de sortida");
		}

		RespostaRegistre resposta = new RespostaRegistre();
		if(numeroAleatori<=25){
			resposta.setResultat(true);
			resposta.setIdTransaccio(transaccio.getIdTransaccio());
			resposta.setTipus(transaccio.getTipus().name());
			resposta.setNumeroAssentament(numeroAssentament);
			resposta.setDataAssentament(formatDate(dataAssentament));
			resposta.setDataPresentacio(formatDate(dataPresentacio));

			//Temps d'espera al·leatori entre 0 i 12.5 segons per a simular situacions de timeout o temps de resposta alts
			try{Thread.sleep(500 * getNumeroAleatori(0, 25));}catch(InterruptedException i){}
		}else{
			// Simulem un error del registre electrònic
			resposta.setResultat(false);
			resposta.setCodiError(23);
			resposta.setMissatgeError("La oficina de registre no pertany a aquest organisme");
		}

		return resposta;
	}

	private static String formatDate(Date calendar) {
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ss.SSSZZZZZ");
		fmt.setCalendar(GregorianCalendar.getInstance());
		StringBuilder dateAsString = new StringBuilder(fmt.format(calendar.getTime()));
		dateAsString.insert(dateAsString.length()-2, ':');
		return dateAsString.toString();
	}

	private static String generaNumeroAssentament(Transaccio transaccio, AtomicInteger comptador){
		return String.format("%s/%10s/%d", transaccio.getTipus().name(), comptador.incrementAndGet(), Calendar.getInstance().get(Calendar.YEAR)).replace(' ', '0');
	}

	private static int getNumeroAleatori(int min, int max){
		return random.nextInt(max - min + 1) + min;
	}
}
