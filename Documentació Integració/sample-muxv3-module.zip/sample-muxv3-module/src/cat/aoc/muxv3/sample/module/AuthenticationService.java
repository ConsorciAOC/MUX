package cat.aoc.muxv3.sample.module;

import javax.servlet.http.HttpServletRequest;


public class AuthenticationService {

	private static final String AUTHORIZATION_HEADER = "Authorization";
	
	private static final String BEARER = "Bearer";


	public AuthResult authenticate(HttpServletRequest request) {

		String authorization = request.getHeader(AUTHORIZATION_HEADER);

		if(authorization==null) {
			return new AuthResult("No s'ha trobat la capçalera d'autenticació.");
		}

		String[] authorizationParts = authorization.split(" ");
		
		if(authorizationParts.length!=2) {
			return new AuthResult("El format de la capçalera 'Authorization' no és correcte.");
		}

		if(!BEARER.equalsIgnoreCase(authorizationParts[0])) {
			return new AuthResult("Només es suporta els tokens de tipus 'Bearer'.");
		}

		// Per a l'exercici d'exemple assumim que el token JWS és vàlid

		AuthResult positive = new AuthResult();
		positive.setAuthenticated(true);
		positive.setAuthorized(true);
		positive.setMessage("OK");

		return positive;
	}
	
	public static class AuthResult {

		private boolean authenticated;
		
		private boolean authorized;
		
		private String message;


		public AuthResult() {
			authenticated = false;
			authorized = false;
		}

		public AuthResult(String message) {
			this.authenticated = false;
			this.authorized = false;
			this.message = message;
		}

		public boolean isAuthenticated() {
			return authenticated;
		}

		public void setAuthenticated(boolean authenticated) {
			this.authenticated = authenticated;
		}

		public boolean isAuthorized() {
			return authorized;
		}

		public void setAuthorized(boolean authorized) {
			this.authorized = authorized;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}
	}
}
