package cat.aoc.muxv3.sample.module;

import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import cat.aoc.mux.v3.beans.Transaccio;
import cat.aoc.mux.v3.registres.beans.RespostaRegistre;

/**
 * Exemple de controlador d'execució de les transaccions.
 * 
 * Aquest controlador manté un mapa on per a cada transacció es guarda un apuntador cap a la tasca d'invocació de la lògica de 
 * generació del número d'assentament. El comportament d'aquest controlador és com segueix:
 *
 *  - Es rep una petició
 *  - El controlador mira si per a la transacció (id + tipus) existeix una tasca d'obtenció del número d'assentament, ja sigui en curs o finalitzada.
 *  - Si existeix una tasca finalitzada es retorna directament el resultat obtingut (número d'assentament o error no recuperable).
 *  - Si no existeix una tasca o si el resultat és un error recuperable es llança en un fil d'execució a banda la tasca d'obtenció del número d'assentament. 
 *  - El controlador espera fins a 10 segons a que la tasca finalitzi.
 *  - Si la tasca finalitza en menys de 10 segons, es retorna el resultat cap al peticionari.
 *  - Si la tasca triga més de 10 segons es retorna un missatge de temps màxim exhaurit però la tasca segueix executant-se.
 * 
 * ATENCIO: Aquest codi està dissenyat únicament a mode d'exemple i no suporta l'execució en més d'un node ja que es recolza en la memòria local
 * per a mantenir la informació de control de les tasques. En cap cas s'ha de prendre aquest codi com a una implementació vàlida per a un entorn productiu.
 * 
 **/

public class ExecutorPeticions {

	private static final Map<String, Future<RespostaRegistre>> transaccionsProcessades = new ConcurrentHashMap<>(); 

	private static final ThreadPoolExecutor _threadpool = new ThreadPoolExecutor(25, 100, 60, TimeUnit.SECONDS, new ArrayBlockingQueue<>(1000));


	public static RespostaRegistre run(Transaccio transaccio, Integer tempsMaximEspera, TimeUnit unitatTempsEspera) throws Exception {

		RespostaRegistre resposta = null;
		Future<RespostaRegistre> future = null;

		String transactionKey = transaccio.getIdTransaccio() + "." + transaccio.getTipus().name(); 

		future = transaccionsProcessades.get(transactionKey);
		if(future==null){
			future = _threadpool.submit(()->{
				return RegistreElectronic.invoca(transaccio);
			});
			transaccionsProcessades.put(transactionKey, future);
		}

		try {
			resposta = future.get(tempsMaximEspera, unitatTempsEspera);
		} catch(InterruptedException i) {
			i.printStackTrace();
		} catch(ExecutionException e) {
			throw (Exception)e.getCause();
		} catch(TimeoutException t) {
			throw new Exception("No s'ha obtingut resposta del registre electrònic en el temps màxim establert (" + tempsMaximEspera + " " + unitatTempsEspera + ")");
		}

		// Si la resposta és d'error, eliminem la informació de control per a permetre que la transacció pugui tornar a ser processada
		// pel registre electrònic
		if(resposta!=null && !resposta.getResultat()){
			transaccionsProcessades.remove(transactionKey);
		}

		return resposta;
	}
}
