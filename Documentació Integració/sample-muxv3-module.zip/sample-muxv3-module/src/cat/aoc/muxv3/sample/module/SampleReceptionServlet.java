package cat.aoc.muxv3.sample.module;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.naming.AuthenticationException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import cat.aoc.mux.v3.beans.TipusTransaccio;
import cat.aoc.mux.v3.beans.Transaccio;
import cat.aoc.mux.v3.registres.beans.RespostaRegistre;
import cat.aoc.muxv3.sample.module.AuthenticationService.AuthResult;

/**
 * Servlet de recepció de les peticions provinents de MUX
 */

@WebServlet("/registre")
public class SampleReceptionServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static final Integer CODI_ERROR_METODE_INCORRECTE = 400;

	private static final Integer CODI_ERROR_NO_CONTROLAT = 999;
	
	private static final Integer CODI_ERROR_NO_AUTORITZAT = 403;

	private static final ObjectMapper _mapper = new ObjectMapper();
	
	private static final AuthenticationService authenticationService = new AuthenticationService();

	static{
		_mapper.setSerializationInclusion(Include.NON_NULL);
	}
       
    public SampleReceptionServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		RespostaRegistre resposta = new RespostaRegistre();

		try{
			resposta = buildRespostaRegiostre(false, CODI_ERROR_METODE_INCORRECTE, "Mètode HTTP GET no suportat");
		}catch(Exception e){
			resposta = buildRespostaRegiostre(false, CODI_ERROR_NO_CONTROLAT, e.getMessage());
		}finally{
			writeResponse(response, resposta);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		RespostaRegistre resposta = null;

		try{
			// Autenticació/Autorització
			AuthResult authResult = authenticationService.authenticate(request);
			
			if(!authResult.isAuthenticated() || !authResult.isAuthorized()){
				throw new AuthenticationException(authResult.getMessage());
			}

			// Parseig de la transacció MUXv3
			Transaccio transaccio = _mapper.readValue(request.getInputStream(), Transaccio.class);
			comprovaTipus(transaccio);

			// Invocació del registre electrònic
			resposta = ExecutorPeticions.run(transaccio, 10, TimeUnit.SECONDS);
		}catch(AuthenticationException e){
			resposta = buildRespostaRegiostre(false, CODI_ERROR_NO_AUTORITZAT, e.getMessage());
		}catch(Exception e){
			resposta = buildRespostaRegiostre(false, CODI_ERROR_NO_CONTROLAT, e.getMessage());
		}finally{
			writeResponse(response, resposta);
		}
	}

	private static void comprovaTipus(Transaccio transaccio) throws Exception {
		TipusTransaccio tipusTransascio = transaccio.getTipus();
		if(tipusTransascio==null){
			throw new Exception("El tipus d'assentament és obligatori (E=Entrada, S=Sortida)");
		}
	}

	private static RespostaRegistre buildRespostaRegiostre(boolean resultat, int errorCode, String message) {
		RespostaRegistre resposta = new RespostaRegistre();
		resposta.setResultat(resultat);
		resposta.setCodiError(errorCode);
		resposta.setMissatgeError(message);
		return resposta;
	}

	private static void writeResponse(HttpServletResponse response, RespostaRegistre resposta) throws JsonGenerationException, JsonMappingException, IOException{

		if(resposta==null) {
			resposta = new RespostaRegistre();
			resposta.setResultat(false);
			resposta.setCodiError(CODI_ERROR_NO_CONTROLAT);
			resposta.setMissatgeError("No s'ha obtingut resposta del registre electrònic");
		}

		response.setHeader("Content-Type", "application/json;charset=\"utf-8\"");
		_mapper.writerWithDefaultPrettyPrinter().writeValue(response.getOutputStream(), resposta);
	}
}
